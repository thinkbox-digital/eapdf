/*
 * {{{ header & license
 * Copyright (c) 2004, 2005 Torbj�rn Gannholm
 * Copyright (c) 2006 Wisconsin Court System
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * }}}
 */
package com.openhtmltopdf.pdfboxout;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import java.util.logging.Level;

import com.openhtmltopdf.extend.FSImage;
import com.openhtmltopdf.layout.SharedContext;
import com.openhtmltopdf.outputdevice.helper.ExternalResourceControlPriority;
import com.openhtmltopdf.outputdevice.helper.ExternalResourceType;
import com.openhtmltopdf.render.FSSVGImage;
import com.openhtmltopdf.resource.ImageResource;
import com.openhtmltopdf.swing.NaiveUserAgent;
import com.openhtmltopdf.util.LogMessageId;
import com.openhtmltopdf.util.SVGUriDetector;
import com.openhtmltopdf.util.XRLog;

public class PdfBoxUserAgent extends NaiveUserAgent {
    private SharedContext _sharedContext;

    private final PdfBoxOutputDevice _outputDevice;

    public PdfBoxUserAgent(PdfBoxOutputDevice outputDevice) {
		super();
		_outputDevice = outputDevice;
    }

    private byte[] readStream(InputStream is) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(is.available());
        byte[] buf = new byte[10240];
        int i;
        while ( (i = is.read(buf)) != -1) {
            out.write(buf, 0, i);
        }
        out.close();
        return out.toByteArray();
    }

    @Override
    public ImageResource getImageResource(String uriStr, ExternalResourceType type) {
        if (!checkAccessAllowed(uriStr, type, ExternalResourceControlPriority.RUN_BEFORE_RESOLVING_URI)) {
            return new ImageResource(uriStr, null);
        }

        String uriResolved = resolveURI(uriStr);

        if (uriResolved == null) {
            XRLog.log(Level.INFO, LogMessageId.LogMessageId2Param.LOAD_URI_RESOLVER_REJECTED_LOADING_AT_URI, "image", uriStr);
           return new ImageResource(uriStr, null);
        }

        if (!checkAccessAllowed(uriResolved, type, ExternalResourceControlPriority.RUN_AFTER_RESOLVING_URI)) {
            return new ImageResource(uriStr, null);
        }

        ImageResource resource = _imageCache.get(uriResolved);

        if (resource != null && resource.getImage() instanceof PdfBoxImage) {
            // Make copy of PdfBoxImage so we don't stuff up the cache.
            PdfBoxImage original = (PdfBoxImage) resource.getImage();
            PdfBoxImage copy = new PdfBoxImage(original.getBytes(), original.getUri(), original.getWidth(), original.getHeight(), original.getXObject());
            return new ImageResource(resource.getImageUri(), copy);
        } else if (resource != null && resource.getImage() instanceof FSSVGImage) {
            // Same again: the size of an SVG image is set by whoever uses it.
            FSSVGImage original = (FSSVGImage) resource.getImage();
            return new ImageResource(resource.getImageUri(), original.copy());
        } else if (resource != null && resource.getImage() == null) {
            // A SVG we already know we can not draw. Remembering that keeps us from
            // fetching and complaining about it again for every box it is painted in.
            return resource;
        }


        InputStream is = openStream(uriResolved);

        if (is != null) {
            try {
                if (uriStr.toLowerCase(Locale.US).endsWith(".pdf")) {
                    // TODO: Implement PDF AS IMAGE
                    // PdfReader reader = _outputDevice.getReader(uri);
                    // PDFAsImage image = new PDFAsImage(uri);
                    // Rectangle rect = reader.getPageSizeWithRotation(1);
                    // image.setInitialWidth(rect.getWidth() *
                    // _outputDevice.getDotsPerPoint());
                    // image.setInitialHeight(rect.getHeight() *
                    // _outputDevice.getDotsPerPoint());
                    // resource = new ImageResource(uriStr, image);
                } else {
                    byte[] imgBytes = readStream(is);

                    if (SVGUriDetector.isSvgUri(uriResolved) ||
                        SVGUriDetector.looksLikeSvgContent(imgBytes)) {

                        FSImage svgImage = buildSVGImage(uriResolved, imgBytes, _sharedContext.getDotsPerPixel());

                        if (svgImage == null) {
                            // Cache the failure so that a background image used on every page
                            // is not loaded, and warned about, once per box painted.
                            ImageResource failed = new ImageResource(uriResolved, null);
                            _imageCache.put(uriResolved, failed);
                            return failed;
                        }

                        _imageCache.put(uriResolved, new ImageResource(uriResolved, svgImage));

                        // Hand out a copy, so that sizing this one does not change the cached image.
                        return new ImageResource(uriResolved, ((FSSVGImage) svgImage).copy());
                    }

                    PdfBoxImage fsImage = new PdfBoxImage(imgBytes, uriStr);
                    scaleToOutputResolution(fsImage);
                    _outputDevice.realizeImage(fsImage);
                    resource = new ImageResource(uriResolved, fsImage);
                }
                _imageCache.put(uriResolved, resource);
            } catch (Exception e) {
                XRLog.log(Level.WARNING, LogMessageId.LogMessageId1Param.EXCEPTION_CANT_READ_IMAGE_FILE_FOR_URI, uriStr, e);
            } finally {
                try {
                    is.close();
                } catch (IOException e) {
                    // ignore
                }
            }
        }

        if (resource != null) {
            resource = new ImageResource(resource.getImageUri(), resource.getImage());
        } else {
            resource = new ImageResource(uriStr, null);
        }

        return resource;
    }

    private void scaleToOutputResolution(PdfBoxImage image) {
        float factor = _sharedContext.getDotsPerPixel();
        if (factor != 1.0f) {
            image.scale((int) (image.getWidth() * factor), (int) (image.getHeight() * factor));
        }
    }

    public SharedContext getSharedContext() {
        return _sharedContext;
    }

    public void setSharedContext(SharedContext sharedContext) {
        _sharedContext = sharedContext;
    }
}
