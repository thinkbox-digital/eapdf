package com.openhtmltopdf.pdfboxout;

import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;

import com.openhtmltopdf.util.LogMessageId;
import org.apache.pdfbox.cos.COSArray;
import org.apache.pdfbox.cos.COSFloat;
import org.apache.pdfbox.cos.COSInteger;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.cos.COSNull;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.documentinterchange.logicalstructure.PDStructureElement;
import org.apache.pdfbox.pdmodel.interactive.documentnavigation.destination.PDDestination;
import org.apache.pdfbox.pdmodel.interactive.documentnavigation.destination.PDPageFitHeightDestination;
import org.apache.pdfbox.pdmodel.interactive.documentnavigation.destination.PDPageXYZDestination;
import org.apache.pdfbox.pdmodel.interactive.documentnavigation.outline.PDDocumentOutline;
import org.apache.pdfbox.pdmodel.interactive.documentnavigation.outline.PDOutlineItem;
import org.apache.pdfbox.pdmodel.interactive.documentnavigation.outline.PDOutlineNode;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.openhtmltopdf.css.style.CalculatedStyle;
import com.openhtmltopdf.layout.SharedContext;
import com.openhtmltopdf.render.Box;
import com.openhtmltopdf.render.PageBox;
import com.openhtmltopdf.render.RenderingContext;
import com.openhtmltopdf.render.displaylist.PagedBoxCollector;
import com.openhtmltopdf.util.XRLog;

public class PdfBoxBookmarkManager {
    private final List<Bookmark> _bookmarks = new ArrayList<>();
    private final PDDocument _writer;
    private final SharedContext _sharedContext;
    private final float _dotsPerPoint;
    private final PdfBoxFastOutputDevice _od;
    private final Document _xml;
    private PDDestination _defaultDestination;

    public PdfBoxBookmarkManager(Document xml, PDDocument doc, SharedContext sharedContext, float dotsPerPoint, PdfBoxFastOutputDevice od) {
        this._writer = doc;
        this._sharedContext = sharedContext;
        this._dotsPerPoint = dotsPerPoint;
        this._od = od;
        this._xml = xml;
    }

    public void writeOutline(RenderingContext c, Box root) {
        if (_bookmarks.size() > 0) {
            // Create a default destination to the top of the first page.
            PDPageFitHeightDestination dest = new PDPageFitHeightDestination();
            dest.setPage(_writer.getPage(0));
            _defaultDestination = dest;

            PDDocumentOutline outline = _writer.getDocumentCatalog().getDocumentOutline();

            if (outline == null) {
                outline = new PDDocumentOutline();
                _writer.getDocumentCatalog().setDocumentOutline(outline);
            }

            writeBookmarks(c, root, outline, _bookmarks);
        }
    }

    private void writeBookmarks(RenderingContext c, Box root, PDOutlineNode parent, List<Bookmark> bookmarks) {
        for (Bookmark bookmark : bookmarks) {
            writeBookmark(c, root, parent, bookmark);
        }
    }

    private void writeBookmark(RenderingContext c, Box root, PDOutlineNode parent, Bookmark bookmark) {
        String href = bookmark.getHRef();
        PDPageXYZDestination target = null;
        Box box = null;
        
        if (href.length() > 0 && href.charAt(0) == '#') {
            box = _sharedContext.getBoxById(href.substring(1));

            if (box != null) {
                target = createBoxDestination(c, _writer, _od, _dotsPerPoint, root, box);
            }
        }
        
        if (target == null) {
            XRLog.log(Level.WARNING, LogMessageId.LogMessageId1Param.GENERAL_PDF_COULD_NOT_FIND_VALID_TARGET_FOR_BOOKMARK, href);
        }

        PDOutlineItem outline = new PDOutlineItem();
        outline.setTitle(bookmark.getName());

        PDStructureElement se = PdfBoxAccessibilityHelper.getStructualElementForBox(box);

        if (_od.getPdfUaVersion() >= 2 && se != null) {
            // PDF/UA-2 (ISO 14289-2, 8.8): every destination targeting the current document
            // must be a structure destination. The same array serves as /Dest (the structure
            // destination form is valid there) and /SD (the PDF 2.0 preferred key).
            COSArray structureDestination = createStructureDestination(se, target);
            outline.getCOSObject().setItem(COSName.DEST, structureDestination);
            outline.getCOSObject().setItem(COSName.getPDFName("SD"), structureDestination);
            outline.setStructureElement(se);
        } else {
            outline.setDestination(target == null ? _defaultDestination : target);
            if (se != null) {
                outline.setStructureElement(se);
            }
        }

        parent.addLast(outline);
        writeBookmarks(c, root, outline, bookmark.getChildren());
    }

    /**
     * Builds a PDF 2.0 structure destination array referencing the given structure element.
     * With a page destination it mirrors its coordinates (<code>[structElem /XYZ left top zoom]</code>);
     * without one it falls back to <code>[structElem /Fit]</code>.
     */
    private static COSArray createStructureDestination(PDStructureElement se, PDPageXYZDestination pageDest) {
        COSArray sd = new COSArray();
        sd.add(se.getCOSObject());

        if (pageDest == null) {
            sd.add(COSName.getPDFName("Fit"));
            return sd;
        }

        sd.add(COSName.getPDFName("XYZ"));

        int left = pageDest.getLeft();
        int top = pageDest.getTop();
        float zoom = pageDest.getZoom();

        sd.add(left >= 0 ? COSInteger.get(left) : COSNull.NULL);
        sd.add(top >= 0 ? COSInteger.get(top) : COSNull.NULL);
        sd.add(zoom > 0 ? new COSFloat(zoom) : COSNull.NULL);

        return sd;
    }

    /**
     * Creates a <code>PDPageXYZDestination</code> with the Y set to the min Y of the border box and 
     * the X and Z set to null. Takes into account any transforms set for the box as well as inserted overflow pages.
     */
    public static PDPageXYZDestination createBoxDestination(
            RenderingContext c, PDDocument writer, PdfBoxFastOutputDevice od, float dotsPerPoint, Box root, Box box) {
        
        List<PageBox> pages = root.getLayer().getPages();
        Rectangle bounds = PagedBoxCollector.findAdjustedBoundsForBorderBox(c, box, pages);

        double destY = bounds.getMinY();

        // When the box straddles a page break its first line of content may have been
        // pushed to a later page than its top edge. In that case anchor the destination
        // to the content start so it points at the page where the content actually paints.
        // Content start is in untransformed document coordinates, so only use it when no
        // transform is in effect.
        if (box.getContainingLayer().getCurrentTransformMatrix() == null) {
            int contentStartY = PagedBoxCollector.findContentStartY(box);
            if (PagedBoxCollector.findPageForY(c, contentStartY, pages) >
                    PagedBoxCollector.findPageForY(c, destY, pages)) {
                destY = contentStartY;
            }
        }

        int pageBoxIndex = PagedBoxCollector.findPageForY(c, destY, pages);
        PageBox page = pages.get(pageBoxIndex);

        int distanceFromTop = page.getMarginBorderPadding(c, CalculatedStyle.TOP);
        distanceFromTop += destY - page.getTop();

        int shadowPage = PagedBoxCollector.getShadowPageForBounds(c, bounds, page);

        int pdfPageIndex = shadowPage == -1 ? page.getBasePagePdfPageIndex() : shadowPage + 1 + page.getBasePagePdfPageIndex();

        PDPageXYZDestination target = new PDPageXYZDestination();
        target.setTop((int) (od.normalizeY(distanceFromTop, page.getHeight(c)) / dotsPerPoint));
        target.setPage(writer.getPage(pdfPageIndex));
        
        return target;
    }

    public void loadBookmarks() {
        Document doc = _xml;
        Element head = DOMUtil.getChild(doc.getDocumentElement(), "head");
        Element body = DOMUtil.getChild(doc.getDocumentElement(), "body");
        handleBookmarksInParent(head);
        handleBookmarksInParent(body);
    }

    private void handleBookmarksInParent(Element element) {
        if (element != null) {
            Element bookmarks = DOMUtil.getChild(element, "bookmarks");
            if (bookmarks != null) {
                List<Element> l = DOMUtil.getChildren(bookmarks, "bookmark");
                if (l != null) {
                    for (Element e : l) {
                        loadBookmark(null, e);
                    }
                }
            }
        }
    }

    private void loadBookmark(Bookmark parent, Element bookmark) {
        Bookmark us = new Bookmark(bookmark.getAttribute("name"), bookmark.getAttribute("href"));
        if (parent == null) {
            _bookmarks.add(us);
        } else {
            parent.addChild(us);
        }
        List<Element> l = DOMUtil.getChildren(bookmark, "bookmark");
        if (l != null) {
            for (Element e : l) {
                loadBookmark(us, e);
            }
        }
    }

    private static class Bookmark {
        private final String _name;
        private final String _HRef;

        private List<Bookmark> _children;

        public Bookmark(String name, String href) {
            _name = name;
            _HRef = href;
        }

        public String getHRef() {
            return _HRef;
        }

        public String getName() {
            return _name;
        }

        public void addChild(Bookmark child) {
            if (_children == null) {
                _children = new ArrayList<>();
            }
            _children.add(child);
        }

        public List<Bookmark> getChildren() {
            return _children == null ? Collections.<Bookmark>emptyList() : _children;
        }
    }
}
