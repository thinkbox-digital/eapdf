/*
 * {{{ header & license
 * Copyright (c) 2006 Wisconsin Court System
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * }}}
 */
package com.openhtmltopdf.pdfboxout;

import com.openhtmltopdf.pdfboxout.PdfBoxFontResolver.FontDescription;
import com.openhtmltopdf.render.FSFont;

import java.util.List;

public class PdfBoxFSFont implements FSFont {
    private final List<FontDescription> _fonts;
    private final float _size;
    private final boolean _kerning;

    public PdfBoxFSFont(List<FontDescription> fonts, float size) {
        this(fonts, size, false);
    }

    /**
     * @param kerning whether left-to-right runs in this font are measured and
     * drawn with the pair kerning of its fonts
     */
    public PdfBoxFSFont(List<FontDescription> fonts, float size, boolean kerning) {
        _fonts = fonts;
        _size = size;
        _kerning = kerning;
    }

    @Override
    public float getSize2D() {
        return _size;
    }

    public List<FontDescription> getFontDescriptions() {
        return _fonts;
    }

    /**
     * Whether left-to-right runs in this font are kerned, as resolved from the
     * <code>font-kerning</code> property, see {@link PdfBoxKerning}.
     */
    public boolean isKerning() {
        return _kerning;
    }
}
