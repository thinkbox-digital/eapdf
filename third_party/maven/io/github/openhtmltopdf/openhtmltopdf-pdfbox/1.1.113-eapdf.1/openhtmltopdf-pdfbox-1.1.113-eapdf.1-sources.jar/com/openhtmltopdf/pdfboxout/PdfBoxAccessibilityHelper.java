package com.openhtmltopdf.pdfboxout;

import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Deque;
import java.util.ArrayDeque;
import org.apache.pdfbox.pdmodel.graphics.form.PDFormXObject;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;
import java.util.logging.Level;

import com.openhtmltopdf.util.LogMessageId;
import org.apache.pdfbox.cos.COSArray;
import org.apache.pdfbox.cos.COSDictionary;
import org.apache.pdfbox.cos.COSInteger;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDNumberTreeNode;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.documentinterchange.logicalstructure.PDMarkedContentReference;
import org.apache.pdfbox.pdmodel.documentinterchange.logicalstructure.PDObjectReference;
import org.apache.pdfbox.pdmodel.documentinterchange.logicalstructure.PDStructureElement;
import org.apache.pdfbox.pdmodel.documentinterchange.logicalstructure.PDStructureTreeRoot;
import org.apache.pdfbox.pdmodel.documentinterchange.markedcontent.PDMarkedContent;
import org.apache.pdfbox.pdmodel.documentinterchange.taggedpdf.StandardStructureTypes;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotation;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.openhtmltopdf.css.constants.CSSName;
import com.openhtmltopdf.css.constants.IdentValue;
import com.openhtmltopdf.extend.StructureType;
import com.openhtmltopdf.newtable.TableBox;
import com.openhtmltopdf.newtable.TableCellBox;
import com.openhtmltopdf.render.BlockBox;
import com.openhtmltopdf.render.Box;
import com.openhtmltopdf.render.InlineLayoutBox;
import com.openhtmltopdf.render.LineBox;
import com.openhtmltopdf.render.MarkerData;
import com.openhtmltopdf.render.RenderingContext;
import com.openhtmltopdf.render.ViewportBox;
import com.openhtmltopdf.render.displaylist.DisplayListContainer;
import com.openhtmltopdf.render.displaylist.PaintInlineContent;
import com.openhtmltopdf.util.XRLog;
import java.util.IdentityHashMap;
import java.util.HashSet;
import java.util.Arrays;

public class PdfBoxAccessibilityHelper {
    // This maps from page to a list of content items, we need to process in page order, so a linked map.
    private final Map<PDPage, PageItems> _pageItemsMap = new LinkedHashMap<>();
    private final PdfBoxFastOutputDevice _od;
    private final Box _rootBox;
    private final Document _doc;
    private final GenericStructualElement _root;
    private final int _pdfUaVersion;

    // ISO 32000-2 / ISO 32005 standard structure namespace (PDF 2.0).
    private static final String PDF2_STRUCTURE_NAMESPACE = "http://iso.org/pdf2/ssn";
    // The /NS key, set both on the namespace dictionary and on each structure element.
    private static final COSName NS = COSName.getPDFName("NS");

    private static final Map<String, Supplier<AbstractStructualElement>> _tagSuppliers = createTagSuppliers();

    private int _nextMcid;

    // These change with every page, most of them are only needed while we paint the page, so we don't add
    // them to the PageItems class, which is stored for later processing.
    private PageItems _pageItems;
    private PdfContentStreamAdapter _cs;
    private RenderingContext _ctx;
    private PDPage _page;
    private float _pageHeight;
    private AffineTransform _transform;

    private int _runningLevel;

    // see #isTableLayoutArtifact
    private IdentityHashMap<Box, List<Integer>> _boxToPageMapping;

    /**
     * When non-null, we are inside a running element that contains a link.
     * Text content that is a DOM descendant of this link will get proper
     * /Link structure elements instead of being marked as artifact.
     */
    private AnchorStuctualElement _runningLinkStructure;
    private org.w3c.dom.Element _runningLinkDomElement;

    /**
     * Maps anchor DOM elements in running content to their /Link structure elements.
     * Running content box objects are re-created per page, so we track by DOM element
     * to reuse the same structure element across pages.
     */
    private final Map<org.w3c.dom.Element, AnchorStuctualElement> _runningLinkCache = new HashMap<>();

    private static Map<String, Supplier<AbstractStructualElement>> createTagSuppliers() {
        Map<String, Supplier<AbstractStructualElement>> suppliers = new HashMap<>();

        suppliers.put("ul", ListStructualElement::new);
        suppliers.put("ol", ListStructualElement::new);
        suppliers.put("li", ListItemStructualElement::new);

        suppliers.put("dl", DescriptionListStructualElement::new);
        suppliers.put("dt", DescriptionTermStructualElement::new);
        suppliers.put("dd", DescriptionDetailsStructualElement::new);

        suppliers.put("table", TableStructualElement::new);
        suppliers.put("tr", TableRowStructualElement::new);
        suppliers.put("td", TableCellStructualElement::new);
        suppliers.put("th", TableHeaderStructualElement::new);

        suppliers.put("a", AnchorStuctualElement::new);
        suppliers.put("abbr", AbbrStuctualElement::new);

        return suppliers;
    }

    public PdfBoxAccessibilityHelper(PdfBoxFastOutputDevice od, Box root, Document doc) {
        this(od, root, doc, 1);
    }

    public PdfBoxAccessibilityHelper(PdfBoxFastOutputDevice od, Box root, Document doc, int pdfUaVersion) {
        this._od = od;
        this._rootBox = root;
        this._doc = doc;
        this._pdfUaVersion = pdfUaVersion;
        this._root = new GenericStructualElement();
        this._root.box = root;
        root.setAccessiblityObject(this._root);
    }

    private static class PageItems {
        final List<GenericContentItem> _contentItems = new ArrayList<>();
        final List<AnnotationWithStructureParent> _pageAnnotations = new ArrayList<>();

        // The transparency group form whose stream holds these content items, or
        // null when it is the page's own stream.
        final PDFormXObject _form;

        PageItems(PDFormXObject form) {
            _form = form;
        }
    }

    /**
     * The content stream marked content is written to while a transparency group is
     * open around it: MCIDs are numbered per content stream, from 0.
     */
    private static class StreamTarget {
        final PdfContentStreamAdapter cs;
        final int nextMcid;
        final PageItems items;

        StreamTarget(PdfContentStreamAdapter cs, int nextMcid, PageItems items) {
            this.cs = cs;
            this.nextMcid = nextMcid;
            this.items = items;
        }
    }

    // The stream that marked content goes into now: the page's, or a group's form.
    private PageItems _streamItems;
    private final Deque<StreamTarget> _outerStreams = new ArrayDeque<>();
    private final List<PageItems> _groupItems = new ArrayList<>();

    /**
     * Can be either a structure element or a content item.
     */
    private static abstract class AbstractTreeItem {
        AbstractStructualElement parent;
        abstract void finish(AbstractStructualElement parent);
    }

    private static abstract class AbstractStructualElement extends AbstractTreeItem {
        Box box;
        PDStructureElement elem;
        PDStructureElement parentElem; // May be different from this.parent.elem if we skip boxes in the tree.
        PDPage page;

        abstract void addChild(AbstractTreeItem child);
        abstract String getPdfTag();

        void createPdfStrucureElement(AbstractStructualElement parent, AbstractStructualElement child) {
            child.parentElem = parent.elem;
            child.elem = new PDStructureElement(child.getPdfTag(), child.parentElem);
            child.elem.setParent(child.parentElem);
            child.elem.setPage(child.page);

            child.parentElem.appendKid(child.elem);
        }

        /**
         * Handles globally valid HTML attributes such as title and lang.
         */
        void handleGlobalAttributes() {
            handleLangAttribute();
            handleTitleAttribute();
        }

        void handleLangAttribute() {
            if (box != null && box.getElement() != null) {
                String lang = box.getElement().getAttribute("lang");
                if (!lang.isEmpty()) {
                    this.elem.setLanguage(lang);
                }
            }
        }

        void handleTitleAttribute() {
            if (box != null && box.getElement() != null) {
                String alternate = box.getElement().getAttribute("title");
                if (!alternate.isEmpty()) {
                    this.elem.setAlternateDescription(alternate);
                }
            }
        }

        /**
         * Only a couple of types of structural elements need the PDF version
         * so leave empty in the base class.
         */
        void setPdfVersion(float version) { }

        /**
         * The optional attribute dictionary is used for additional information about
         * the structural element such as bounding box, cell spans, etc.
         * NOTE: This only allows one attribute dictionary (possibly with multiple attributes) with one owner.
         */
        void setAttributeDictionary(COSDictionary attrDict) {
            // NOTE: We could do this instead:
            //   this.elem.addAttribute(PDAttributeObject.create(attrDict));
            // However, PDFBOX adds a revision number.
            // This is allowed by the spec but causes the PDF Accessiblity Checker (PAC)
            // to crash.
            this.elem.getCOSObject().setItem(COSName.A, attrDict);
        }

        @Override
        public String toString() {
            return String.format("[Structual Element-%s:%s]", super.toString(), box);
        }
    }

    private static class GenericStructualElement extends AbstractStructualElement {
        final List<AbstractTreeItem> children = new ArrayList<>();

        /**
         * Set in {@link #finish(AbstractStructualElement)} when a plain block div holds
         * only inline content and is tagged P instead of Div.
         */
        private String tagOverride;

        @Override
        String getPdfTag() {
            return tagOverride != null ? tagOverride : chooseTag(this.box);
        }

        @Override
        void addChild(AbstractTreeItem child) {
            this.children.add(child);
        }

        private String chooseTag(Box box) {
            if (box != null) {
                if (box.getLayer() != null) {
                    return StandardStructureTypes.SECT;
                } else if (box.isAnonymous()) {
                    return guessBoxTag(box);
                } else if (box.getElement() != null) {
                    String htmlTag = box.getElement().getTagName();

                    switch (htmlTag) {
                    case "p":
                        return StandardStructureTypes.P;
                    case "h1":
                        return StandardStructureTypes.H1;
                    case "h2":
                        return StandardStructureTypes.H2;
                    case "h3":
                        return StandardStructureTypes.H3;
                    case "h4":
                        return StandardStructureTypes.H4;
                    case "h5":
                        return StandardStructureTypes.H5;
                    case "h6":
                        return StandardStructureTypes.H6;
                    case "article": // Fall-thru
                    case "art":
                        return StandardStructureTypes.ART;
                    case "part":
                        return StandardStructureTypes.PART;
                    case "section": // Fall-thru
                    case "sect":
                        return StandardStructureTypes.SECT;
                    case "caption":
                        return StandardStructureTypes.CAPTION;
                    case "blockquote":
                        return StandardStructureTypes.BLOCK_QUOTE;
                    case "div":
                        // HTML div is always a block-level container in the PDF
                        // structure tree, regardless of CSS display:inline-block.
                        // Falling through to guessBoxTag would emit Span for an
                        // inline-block div, producing Span containing P which
                        // PAC flags as inappropriate use of Span.
                        return StandardStructureTypes.DIV;
                    case "dt": // Fall-thru
                    case "dd":
                        // A dt/dd inside a dl never gets here: DescriptionListStructualElement
                        // regroups its content into the Lbl/LBody of a synthetic LI. This only
                        // applies to a dt/dd outside a dl.
                        //
                        // dd takes flow content, so block children (<dd><p>, <dd><ul>, ...)
                        // nest legally in a Div. Inline content must not sit directly in a
                        // Div (a Grouping element), and wrapping it in a Span only to satisfy
                        // nesting is flagged by PAC as inappropriate use of Span. So map to P
                        // (content-permitting) in the inline case; otherwise fall through to Div.
                        if (box instanceof BlockBox &&
                            ((BlockBox) box).getChildrenContentType() == BlockBox.ContentType.INLINE) {
                            return StandardStructureTypes.P;
                        }
                        break; // block content (or empty/unknown): fall through to Div below.
                    }
                }

                return guessBoxTag(box);
            }

            return StandardStructureTypes.SPAN;
        }

    /**
     * Counts children that are not themselves purely br-generated content.
     * A br-generated child (see isBrGeneratedContent) always ends up contributing
     * zero real content once its own finish() runs - it is either fully empty
     * (the invisible line-break text is now an Artifact, see startStructure/TEXT)
     * or gets flattened away. Without this, such a child would still count
     * towards child.children.size(), so a wrapper box like "Bar<br>" would be
     * seen as having 2 children instead of 1 and miss the single-child collapse
     * below, needlessly getting its own Span. See GH issue #100.
     */
    private static int countNonBrChildren(List<AbstractTreeItem> children) {
        int count = 0;
        for (AbstractTreeItem item : children) {
            if (item instanceof GenericStructualElement &&
                isBrGeneratedContent(((GenericStructualElement) item).box)) {
                continue;
            }
            count++;
        }
        return count;
    }

        /**
         * Whether finishing this element outputs nothing at all.
         */
        boolean isOmitted() {
            // There is no point in outputting empty structual elements.
            // Exception is elements with an id which may be there to
            // use as a link or bookmark destination.
            return children.isEmpty() &&
                   (box.getElement() == null || !box.getElement().hasAttribute("id"));
        }

        /**
         * Whether this element gets no structure element of its own, its children
         * being finished into its parent instead.
         */
        boolean isSkipped() {
            return box instanceof LineBox ||
                   (box instanceof InlineLayoutBox &&
                    countNonBrChildren(children) == 1 &&
                    box.getParent() instanceof LineBox) ||
                   isBrGeneratedContent(box);
        }

        @Override
        void finish(AbstractStructualElement parent) {
            // A structual element such as Div, Sect, p, etc
            // which contains other structual elements or content items (text).
            GenericStructualElement child = this;

            if (child.isOmitted()) {
                return;
            }

            if (child.isSkipped()) {
                // We skip (don't create structure element) line boxes in the tree.
                // We also skip the common case of a intermediary InlineLayoutBox between the 
                // LineBox and a single InlineText.
                // We also skip <br> elements and the anonymous inline box generated for
                // their :before content (the forced line break itself). A <br> has no
                // text-level semantic of its own, so tagging it (or its generated content)
                // as a Span causes "possibly inappropriate use of a Span structure element"
                // warnings in PDF/UA checkers such as PAC. See GH issue #100.
                finishTreeItems(child.children, parent);
            } else if (GROUPING_TAGS.contains(child.getPdfTag()) && !isInlineLevel(child.box)) {
                finishGrouping(parent);
            } else {
                createPdfStrucureElement(parent, child);

                handleGlobalAttributes();

                // Recursively, depth first, process the structual tree.
                finishTreeItems(child.children, child);
            }
        }

        /**
         * A grouping element (Div, Sect, ...) may hold only other structure elements,
         * never content directly (PDF/UA, PDF 1.7 14.8.4.2): each run of inline content in
         * it, its lines and the text-level elements in them, is finished into one P, as
         * an anonymous block of text is a paragraph. A plain div holding nothing but
         * such a run is that P itself, or inside a paragraph or heading, where a P may
         * not go, a Span. See GH issue #225.
         */
        private void finishGrouping(AbstractStructualElement parent) {
            List<AbstractTreeItem> items = new ArrayList<>();
            collectFinishedItems(children, items);

            if (StandardStructureTypes.DIV.equals(getPdfTag()) &&
                box.getLayer() == null &&
                !items.isEmpty() &&
                items.stream().allMatch(GenericStructualElement::isInlineContent)) {
                tagOverride = PARAGRAPH_TAGS.contains(parent.getPdfTag()) ?
                        StandardStructureTypes.SPAN : StandardStructureTypes.P;
            }

            createPdfStrucureElement(parent, this);
            handleGlobalAttributes();

            if (tagOverride != null) {
                finishTreeItems(items, this);
                return;
            }

            List<AbstractTreeItem> run = new ArrayList<>();
            for (AbstractTreeItem item : items) {
                if (isInlineContent(item)) {
                    run.add(item);
                } else {
                    finishParagraph(run);
                    item.finish(this);
                }
            }
            finishParagraph(run);
        }

        private void finishParagraph(List<AbstractTreeItem> run) {
            if (run.isEmpty()) {
                return;
            }

            AnonymousParagraphStructualElement paragraph = new AnonymousParagraphStructualElement();
            paragraph.page = this.page;
            createPdfStrucureElement(this, paragraph);
            finishTreeItems(run, paragraph);
            run.clear();
        }

        /**
         * Collects the items that finishing these children outputs into their parent:
         * those skipped are passed through, those omitted left out.
         */
        private static void collectFinishedItems(List<AbstractTreeItem> children, List<AbstractTreeItem> result) {
            for (AbstractTreeItem item : children) {
                if (item.getClass() == GenericStructualElement.class) {
                    GenericStructualElement generic = (GenericStructualElement) item;
                    if (generic.isOmitted()) {
                        continue;
                    } else if (generic.isSkipped()) {
                        collectFinishedItems(generic.children, result);
                        continue;
                    }
                }
                result.add(item);
            }
        }

        /**
         * Whether this item is content, or an element of the text level, that a
         * grouping element must not hold directly.
         */
        private static boolean isInlineContent(AbstractTreeItem item) {
            if (item instanceof GenericContentItem) {
                return true;
            }

            AbstractStructualElement element = (AbstractStructualElement) item;
            String tag = element.getPdfTag();

            if (INLINE_TAGS.contains(tag)) {
                return true;
            }

            return (StandardStructureTypes.Figure.equals(tag) || StandardStructureTypes.FORMULA.equals(tag)) &&
                   element.box != null && isInlineLevel(element.box);
        }

        private static boolean isInlineLevel(Box box) {
            return box instanceof InlineLayoutBox ||
                   box instanceof LineBox ||
                   (box instanceof BlockBox && ((BlockBox) box).isInline());
        }
    }

    /**
     * The grouping elements of PDF 1.7 (14.8.4.2) that this helper outputs: they may
     * hold other structure elements only.
     */
    private static final Set<String> GROUPING_TAGS = new HashSet<>(Arrays.asList(
            StandardStructureTypes.DIV,
            StandardStructureTypes.SECT,
            StandardStructureTypes.ART,
            StandardStructureTypes.PART,
            StandardStructureTypes.BLOCK_QUOTE,
            StandardStructureTypes.CAPTION));

    /**
     * The paragraph-like elements of PDF 1.7 (14.8.4.3), which hold text, but no P.
     */
    private static final Set<String> PARAGRAPH_TAGS = new HashSet<>(Arrays.asList(
            StandardStructureTypes.P,
            StandardStructureTypes.H,
            StandardStructureTypes.H1,
            StandardStructureTypes.H2,
            StandardStructureTypes.H3,
            StandardStructureTypes.H4,
            StandardStructureTypes.H5,
            StandardStructureTypes.H6));

    /**
     * The inline-level structure elements of PDF 1.7 (14.8.4.4) that this helper outputs.
     */
    private static final Set<String> INLINE_TAGS = new HashSet<>(Arrays.asList(
            StandardStructureTypes.SPAN,
            StandardStructureTypes.QUOTE,
            StandardStructureTypes.NOTE,
            StandardStructureTypes.REFERENCE,
            StandardStructureTypes.BIB_ENTRY,
            StandardStructureTypes.CODE,
            StandardStructureTypes.LINK,
            StandardStructureTypes.ANNOT,
            StandardStructureTypes.RUBY,
            StandardStructureTypes.WARICHU));

    /**
     * The P that holds a run of inline content in a grouping element.
     */
    private static class AnonymousParagraphStructualElement extends AbstractStructualElement {
        @Override
        String getPdfTag() {
            return StandardStructureTypes.P;
        }

        @Override
        void addChild(AbstractTreeItem child) {
            throw new UnsupportedOperationException();
        }

        @Override
        void finish(AbstractStructualElement parent) {
            throw new UnsupportedOperationException();
        }
    }

    private static class AnchorStuctualElement extends GenericStructualElement {
        @Override
        String getPdfTag() {
            return StandardStructureTypes.LINK;
        }

        @Override
        void finish(AbstractStructualElement parent) {
            AnchorStuctualElement child = this;

            createPdfStrucureElement(parent, child);

            String alternate = box.getElement() != null ? box.getElement().getAttribute("title") : "";
            if (alternate.isEmpty()) {
                XRLog.log(Level.INFO, LogMessageId.LogMessageId1Param.GENERAL_PDF_ACCESSIBILITY_NO_TITLE_TEXT_PROVIDED_FOR, "link");
            }
            child.elem.setAlternateDescription(alternate);

            handleLangAttribute();

            finishTreeItems(child.children, child);
        }
    }

    private static class AbbrStuctualElement extends GenericStructualElement {
        float pdfVersion = 1.5f;

        @Override
        String getPdfTag() {
            return StandardStructureTypes.SPAN;
        }

        @Override
        void finish(AbstractStructualElement parent) {
            AbbrStuctualElement child = this;

            createPdfStrucureElement(parent, child);

            if (box.getElement() != null) {
                String expanded = box.getElement().getAttribute("title");
                if (!expanded.isEmpty()) {
                    if (pdfVersion < 1.5f) {
                        // The expanded entry for structural elements was only introduced in 1.5.
                        child.elem.setAlternateDescription(expanded);
                    } else {
                        child.elem.setExpandedForm(expanded);
                    }
                } else {
                    XRLog.log(Level.INFO, LogMessageId.LogMessageId1Param.GENERAL_PDF_ACCESSIBILITY_NO_TITLE_TEXT_PROVIDED_FOR, "abbr tag");
                }

                handleLangAttribute();
            }

            finishTreeItems(child.children, child);
        }

        @Override
        void setPdfVersion(float version) {
            this.pdfVersion = version;
        }
    }

    private static class ListStructualElement extends AbstractStructualElement {
        final List<ListItemStructualElement> listItems = new ArrayList<>();

        @Override
        String getPdfTag() {
            return StandardStructureTypes.L;
        }

        @Override
        void addChild(AbstractTreeItem child) {
            if (child instanceof ListItemStructualElement) {
                this.listItems.add((ListItemStructualElement) child);
            } else {
                logIncompatibleChild(this, child, ListItemStructualElement.class);
            }
        }

        @Override
        void finish(AbstractStructualElement parent) {
            ListStructualElement child = this;

            createPdfStrucureElement(parent, child);

            IdentValue listStyleType = child.box.getStyle().getIdent(CSSName.LIST_STYLE_TYPE);
            String listType;

            if (listStyleType == IdentValue.NONE) {
                listType = "None";
            } else if (listStyleType == IdentValue.DISC) {
                listType = "Disc";
            } else if (listStyleType == IdentValue.SQUARE) {
                listType = "Square";
            } else if (listStyleType == IdentValue.CIRCLE) {
                listType = "Circle";
            } else if (listStyleType == IdentValue.DECIMAL ||
                       listStyleType == IdentValue.DECIMAL_LEADING_ZERO) {
                listType = "Decimal";
            } else if (listStyleType == IdentValue.UPPER_ROMAN) {
                listType = "UpperRoman";
            } else if (listStyleType == IdentValue.LOWER_ROMAN) {
                listType = "LowerRoman";
            } else if (listStyleType == IdentValue.UPPER_ALPHA) {
                listType = "UpperAlpha";
            } else if (listStyleType == IdentValue.LOWER_ALPHA) {
                listType = "LowerAlpha";
            } else if (listStyleType == IdentValue.ARABIC_INDIC) {
                listType = "Ordered";
            } else {
                // Armenian, Georgian, Latin and Greek are not supported by the PDF spec.
                listType = "Decimal";
            }

            COSDictionary listNumbering = new COSDictionary();
            listNumbering.setItem(COSName.O, COSName.getPDFName("List"));
            listNumbering.setItem(COSName.getPDFName("ListNumbering"), COSName.getPDFName(listType));
            setAttributeDictionary(listNumbering);

            handleGlobalAttributes();

            finishTreeItems(child.listItems, child);
        }
    }

    private static class ListItemStructualElement extends AbstractStructualElement {
        final ListLabelStructualElement label;
        final ListBodyStructualElement body;

        ListItemStructualElement() {
            this.body = new ListBodyStructualElement();
            this.body.parent = this;

            this.label = new ListLabelStructualElement();
            this.label.parent = this;
        }

        @Override
        String getPdfTag() {
            return StandardStructureTypes.LI;
        }

        @Override
        void addChild(AbstractTreeItem child) {
            this.body.addChild(child);
        }

        @Override
        void finish(AbstractStructualElement parent) {
            ListItemStructualElement child = this;

            createPdfStrucureElement(parent, child);

            handleGlobalAttributes();

            finishTreeItem(child.label, child);
            finishTreeItem(child.body, child);
        }
    }

    private static class ListLabelStructualElement extends AbstractStructualElement {
        final List<AbstractTreeItem> children = new ArrayList<>(1);

        @Override
        String getPdfTag() {
            return StandardStructureTypes.LBL;
        }

        @Override
        void addChild(AbstractTreeItem child) {
            this.children.add(child);
        }

        @Override
        void finish(AbstractStructualElement parent) {
            ListLabelStructualElement child = this;

            if (child.children.isEmpty()) {
                // Must be list-style-type: none.
                return;
            }

            createPdfStrucureElement(parent, child);

            handleGlobalAttributes();

            finishTreeItems(child.children, child);
        }
    }

    private static class ListBodyStructualElement extends GenericStructualElement {
        @Override
        String getPdfTag() {
            return StandardStructureTypes.L_BODY;
        }

        @Override
        void finish(AbstractStructualElement parent) {
            ListBodyStructualElement child = this;

            createPdfStrucureElement(parent, child);

            handleGlobalAttributes();

            finishTreeItems(child.children, child);
        }
    }

    /**
     * A dt or dd. Inside a dl, DescriptionListStructualElement moves its children
     * into the Lbl/LBody of a synthetic LI and the element itself is never finished.
     * A dt/dd outside a dl is finished like any other element (see chooseTag).
     */
    private abstract static class DescriptionPartStructualElement extends GenericStructualElement {
        void moveChildrenTo(AbstractStructualElement target) {
            for (AbstractTreeItem child : this.children) {
                target.addChild(child);
                child.parent = target;
            }
            this.children.clear();
        }

        abstract boolean isTerm();
    }

    private static class DescriptionTermStructualElement extends DescriptionPartStructualElement {
        @Override
        boolean isTerm() {
            return true;
        }
    }

    private static class DescriptionDetailsStructualElement extends DescriptionPartStructualElement {
        @Override
        boolean isTerm() {
            return false;
        }
    }

    private static class DescriptionListItemStructualElement extends AbstractStructualElement {
        final ListLabelStructualElement label = new ListLabelStructualElement();
        final ListBodyStructualElement body = new ListBodyStructualElement();

        DescriptionListItemStructualElement(AbstractStructualElement first) {
            this.page = first.page;
            this.box = first.box;
            label.parent = this;
            body.parent = this;
        }

        @Override
        String getPdfTag() {
            return StandardStructureTypes.LI;
        }

        void addTerm(DescriptionTermStructualElement term) {
            term.moveChildrenTo(label);
        }

        void addDetails(DescriptionDetailsStructualElement details) {
            details.moveChildrenTo(body);
        }

        @Override
        void addChild(AbstractTreeItem child) {
            body.addChild(child);
            child.parent = body;
        }

        @Override
        void finish(AbstractStructualElement parent) {
            DescriptionListItemStructualElement child = this;
            createPdfStrucureElement(parent, child);
            handleGlobalAttributes();
            finishTreeItem(child.label, child);
            finishTreeItem(child.body, child);
        }
    }

    /**
     * Maps a dl to an L. HTML has no element for a term/description group, so each
     * run of dt elements followed by dd elements becomes a synthetic LI, with the dt
     * content in its Lbl and the dd content in its LBody (PDF 2.0, "Deriving HTML
     * from PDF" 4.3.5.5.2). div wrappers around groups are flattened.
     */
    private static class DescriptionListStructualElement extends AbstractStructualElement {
        final List<AbstractTreeItem> children = new ArrayList<>();

        @Override
        String getPdfTag() {
            return StandardStructureTypes.L;
        }

        @Override
        void addChild(AbstractTreeItem child) {
            children.add(child);
        }

        @Override
        void finish(AbstractStructualElement parent) {
            DescriptionListStructualElement child = this;
            createPdfStrucureElement(parent, child);
            handleGlobalAttributes();
            finishTreeItems(groupDescriptionParts(child.children), child);
        }

        private List<DescriptionListItemStructualElement> groupDescriptionParts(List<AbstractTreeItem> sourceChildren) {
            List<AbstractTreeItem> parts = new ArrayList<>();
            for (AbstractTreeItem child : sourceChildren) {
                collectDescriptionParts(child, parts);
            }

            List<DescriptionListItemStructualElement> result = new ArrayList<>();
            DescriptionListItemStructualElement currentItem = null;
            boolean seenDetails = false;

            for (AbstractTreeItem part : parts) {
                boolean isTerm = part instanceof DescriptionPartStructualElement &&
                        ((DescriptionPartStructualElement) part).isTerm();

                if (currentItem == null || (isTerm && seenDetails)) {
                    currentItem = new DescriptionListItemStructualElement(
                            part instanceof AbstractStructualElement ? (AbstractStructualElement) part : this);
                    result.add(currentItem);
                    seenDetails = false;
                }

                if (isTerm) {
                    currentItem.addTerm((DescriptionTermStructualElement) part);
                } else if (part instanceof DescriptionDetailsStructualElement) {
                    currentItem.addDetails((DescriptionDetailsStructualElement) part);
                    seenDetails = true;
                } else {
                    // Not allowed in a dl, but its content must still be tagged
                    // for PDF/UA, so keep it with the current description.
                    XRLog.log(Level.WARNING, LogMessageId.LogMessageId0Param.GENERAL_PDF_ACCESSIBILITY_UNEXPECTED_DESCRIPTION_LIST_CHILD);
                    currentItem.addChild(part);
                    seenDetails = true;
                }
            }
            return result;
        }

        private void collectDescriptionParts(AbstractTreeItem child, List<AbstractTreeItem> result) {
            if (isDescriptionDivWrapper(child)) {
                for (AbstractTreeItem nestedChild : ((GenericStructualElement) child).children) {
                    collectDescriptionParts(nestedChild, result);
                }
            } else {
                result.add(child);
            }
        }

        private boolean isDescriptionDivWrapper(AbstractTreeItem child) {
            if (!(child instanceof GenericStructualElement) ||
                child instanceof DescriptionPartStructualElement) {
                return false;
            }
            Box box = ((GenericStructualElement) child).box;
            return box != null &&
                   box.getElement() != null &&
                   "div".equals(box.getElement().getTagName());
        }
    }

    private static class TableStructualElement extends AbstractStructualElement {
        final TableHeadStructualElement thead = new TableHeadStructualElement();
        final List<TableBodyStructualElement> tbodies = new ArrayList<>(1);
        final TableFootStructualElement tfoot = new TableFootStructualElement();
        float pdfVersion = 1.5f;

        @Override
        void addChild(AbstractTreeItem child) {
            if (child instanceof TableBodyStructualElement) {
                this.tbodies.add((TableBodyStructualElement) child);
            } else {
                logIncompatibleChild(parent, child, TableBodyStructualElement.class);
            }
        }

        @Override
        void setPdfVersion(float version) {
            this.pdfVersion = version;
        }

        @Override
        String getPdfTag() {
            return StandardStructureTypes.TABLE;
        }

        @Override
        void finish(AbstractStructualElement parent) {
            TableStructualElement child = this;

            createPdfStrucureElement(parent, child);

            handleGlobalAttributes();

            if (pdfVersion < 1.5f) {
                // THead, TBody and TFoot were introduced in PDF 1.5 so if we can not use
                // them then we process their rows directly and add them to the table.
                finishTreeItems(child.thead.children, child);
                child.tbodies.forEach(tbody -> finishTreeItems(tbody.children, child));
                finishTreeItems(child.tfoot.children, child);
            } else {
                finishTreeItem(child.thead, child);
                finishTreeItems(child.tbodies, child);
                finishTreeItem(child.tfoot, child);
            }
        }
    }

    private static class TableHeadStructualElement extends GenericStructualElement {
        @Override
        String getPdfTag() {
            return StandardStructureTypes.T_HEAD;
        }

        @Override
        void addChild(AbstractTreeItem child) {
            if (!(child instanceof TableRowStructualElement)) {
                logIncompatibleChild(this, child, TableRowStructualElement.class);
            }
            super.addChild(child);
        }

        @Override
        void finish(AbstractStructualElement parent) {
            TableHeadStructualElement child = this;
            createPdfStrucureElement(parent, child);

            handleGlobalAttributes();

            finishTreeItems(child.children, child);
        }
    }

    private static class TableBodyStructualElement extends GenericStructualElement {
        @Override
        String getPdfTag() {
            return StandardStructureTypes.T_BODY;
        }

        @Override
        void addChild(AbstractTreeItem child) {
            if (!(child instanceof TableRowStructualElement)) {
                logIncompatibleChild(this, child, TableRowStructualElement.class);
            }
            super.addChild(child);
        }

        @Override
        void finish(AbstractStructualElement parent) {
            TableBodyStructualElement child = this;
            createPdfStrucureElement(parent, child);

            handleGlobalAttributes();

            finishTreeItems(child.children, child);
        }
    }

    private static class TableFootStructualElement extends GenericStructualElement {
        @Override
        String getPdfTag() {
            return StandardStructureTypes.T_FOOT;
        }

        @Override
        void addChild(AbstractTreeItem child) {
            if (!(child instanceof TableRowStructualElement)) {
                logIncompatibleChild(this, child, TableRowStructualElement.class);
            }
            super.addChild(child);
        }

        @Override
        void finish(AbstractStructualElement parent) {
            TableFootStructualElement child = this;
            createPdfStrucureElement(parent, child);

            handleGlobalAttributes();

            finishTreeItems(child.children, child);
        }
    }

    private static class TableRowStructualElement extends GenericStructualElement {
        @Override
        String getPdfTag() {
            return StandardStructureTypes.TR;
        }

        @Override
        void addChild(AbstractTreeItem child) {
            if (!(child instanceof TableHeaderOrCellStructualElement)) {
                logIncompatibleChild(this, child, TableHeaderOrCellStructualElement.class);
            }
            super.addChild(child);
        }

        @Override
        void finish(AbstractStructualElement parent) {
            TableRowStructualElement child = this;
            createPdfStrucureElement(parent, child);

            handleGlobalAttributes();

            finishTreeItems(child.children, child);
        }
    }

    private static abstract class TableHeaderOrCellStructualElement extends GenericStructualElement {
        boolean addCellAttributes(COSDictionary attrDict) {
            TableHeaderOrCellStructualElement child = this;

            boolean added = false;
            int rowSpanAttr = 1;
            int colSpanAttr = 1;

            if (child.box instanceof TableCellBox) {
                TableCellBox cell = (TableCellBox) box;

                colSpanAttr = cell.getStyle().getColSpan();
                rowSpanAttr = cell.getStyle().getRowSpan();
            }

            if (colSpanAttr != 1) {
                added = true;
                attrDict.setInt(COSName.getPDFName("ColSpan"), colSpanAttr);
            }

            if (rowSpanAttr != 1) {
                added = true;
                attrDict.setInt(COSName.getPDFName("RowSpan"), rowSpanAttr);
            }

            return added;
        }
    }

    private static class TableHeaderStructualElement extends TableHeaderOrCellStructualElement {
        @Override
        String getPdfTag() {
            return StandardStructureTypes.TH;
        }

        @Override
        void finish(AbstractStructualElement parent) {
            TableHeaderStructualElement child = this;
            createPdfStrucureElement(parent, child);

            String scope = box.getElement() != null ? box.getElement().getAttribute("scope") : "";

            COSDictionary attrDict = new COSDictionary();
            attrDict.setItem(COSName.O, COSName.getPDFName("Table"));

            if ("row".equals(scope)) {
                attrDict.setItem(COSName.getPDFName("Scope"), COSName.getPDFName("Row"));
            } else {
                attrDict.setItem(COSName.getPDFName("Scope"), COSName.getPDFName("Column"));
            }

            addCellAttributes(attrDict);
            setAttributeDictionary(attrDict);

            handleGlobalAttributes();

            finishTreeItems(child.children, child);
        }
    }

    private static class TableCellStructualElement extends TableHeaderOrCellStructualElement {
        @Override
        String getPdfTag() {
            return StandardStructureTypes.TD;
        }

        @Override
        void finish(AbstractStructualElement parent) {
            TableCellStructualElement child = this;
            createPdfStrucureElement(parent, child);

            COSDictionary attrDict = new COSDictionary();
            attrDict.setItem(COSName.O, COSName.getPDFName("Table"));

            if (addCellAttributes(attrDict)) {
                setAttributeDictionary(attrDict);
            }

            handleGlobalAttributes();

            finishTreeItems(child.children, child);
        }
    }

    private static class FigureStructualElement extends AbstractStructualElement {
        PDRectangle boundingBox;
        FigureContentItem content;

        @Override
        String getPdfTag() {
            return StandardStructureTypes.Figure;
        }

        @Override
        void addChild(AbstractTreeItem child) {
            if (child instanceof FigureContentItem) {
                this.content = (FigureContentItem) child;
            } else {
                logIncompatibleChild(parent, child, FigureContentItem.class);
            }
        }

        @Override
        void finish(AbstractStructualElement parent) {
            // Must be a figure (image or replaced, etc).
            FigureStructualElement child = this;

            child.parentElem = parent.elem;
            child.elem = new PDStructureElement(child.getPdfTag(), child.parentElem);
            child.elem.setParent(child.parentElem);
            child.elem.setPage(child.page);

            // Add alt text.
            String alternateText = child.box.getElement() == null ? "" : box.getElement().getAttribute("alt");
            if (alternateText.isEmpty()) {
                XRLog.log(Level.WARNING, LogMessageId.LogMessageId0Param.GENERAL_PDF_ACCESSIBILITY_NO_ALT_ATTRIBUTE_PROVIDED_FOR_IMAGE);
            }
            child.elem.setAlternateDescription(alternateText);

            handleLangAttribute();

            // Add bounding box attribute.
            COSDictionary attributeDict = new COSDictionary();
            attributeDict.setItem(COSName.BBOX, child.boundingBox);
            attributeDict.setItem(COSName.O, COSName.getPDFName("Layout"));
            setAttributeDictionary(attributeDict);

            child.parentElem.appendKid(child.elem);

            if (child.content != null) {
                finishTreeItem(child.content, child);
            }
        }
    }

    private static class GenericContentItem extends AbstractTreeItem {
        PDStructureElement parentElem;
        int mcid;
        COSDictionary dict;
        // The transparency group form whose stream holds this content, or null.
        PDFormXObject form;
        PDPage page;

        @Override
        public String toString() {
            return String.format("[Content Item-%s:%d]", super.toString(), mcid);
        }

        @Override
        void finish(AbstractStructualElement parent) {
            // A content item (text or replaced image), we need to add it to its parent structual item.
            GenericContentItem child = this;
            boolean isReplaced = child instanceof FigureContentItem;

            if (child.form == null && child.page == parent.page) {
                // If this is on the same page as its parent structual element
                // we can just use the dict with mcid in it only.
                child.parentElem = parent.elem;
                child.parentElem.appendKid(new PDMarkedContent(isReplaced ? COSName.getPDFName("Figure") : COSName.getPDFName("Span"), child.dict));
            } else {
                // Otherwise we need a more complete dict with the page.
                child.parentElem = parent.elem;
                child.dict = new COSDictionary();
                child.dict.setItem(COSName.TYPE, COSName.getPDFName("MCR"));
                child.dict.setItem(COSName.PG, child.page);
                child.dict.setInt(COSName.MCID, child.mcid);
                if (child.form != null) {
                    // The content is in a form's stream, not the page's (14.7.4.3).
                    child.dict.setItem(COSName.getPDFName("Stm"), child.form);
                }

                PDMarkedContentReference ref = new PDMarkedContentReference(child.dict);
                child.parentElem.appendKid(ref);
            }
        }
    }

    private static class FigureContentItem extends GenericContentItem {
    }

    private static void logIncompatibleChild(AbstractTreeItem parent, AbstractTreeItem child, Class<?> expected) {
        XRLog.log(Level.WARNING, LogMessageId.LogMessageId3Param.GENERAL_PDF_ACCESSIBILITY_INCOMPATIBLE_CHILD, child.getClass().getSimpleName(), parent.getClass().getSimpleName(), expected.getSimpleName());
    }

    /**
     * Given a box, gets its structual element.
     */
    public static PDStructureElement getStructualElementForBox(Box targetBox) {
        if (targetBox == null) {
            return null;
        }

        if (targetBox.getAccessibilityObject() instanceof AbstractStructualElement) {
            PDStructureElement elem = ((AbstractStructualElement) targetBox.getAccessibilityObject()).elem;
            if (elem != null) {
                return elem;
            }
        }

        // A box skipped or merged while building the tree has no element of its own.
        // Use the first descendant's so PDF/UA-2 (ISO 14289-2, 8.8) structure
        // destinations still resolve.
        for (int i = 0; i < targetBox.getChildCount(); i++) {
            PDStructureElement childElem = getStructualElementForBox(targetBox.getChild(i));
            if (childElem != null) {
                return childElem;
            }
        }

        return null;
    }

    public void finishPdfUa() {
        PDStructureTreeRoot root = _od.getWriter().getDocumentCatalog().getStructureTreeRoot();
        if (root == null) {
            root = new PDStructureTreeRoot();

            HashMap<String, String> roleMap = new HashMap<>();
            roleMap.put("Annotation", "Span");
            roleMap.put("Artifact", "P");
            roleMap.put("Bibliography", "BibEntry");
            roleMap.put("Chart", "Figure");
            roleMap.put("Diagram", "Figure");
            roleMap.put("DropCap", "Figure");
            roleMap.put("EndNote", "Note");
            roleMap.put("FootNote", "Note");
            roleMap.put("InlineShape", "Figure");
            roleMap.put("Outline", "Span");
            roleMap.put("Strikeout", "Span");
            roleMap.put("Subscript", "Span");
            roleMap.put("Superscript", "Span");
            roleMap.put("Underline", "Span");
            root.setRoleMap(roleMap);

            // PDF/UA-2: the PDF 2.0 structure namespace, on top of the role map above.
            COSDictionary structureNamespace = createPdf2StructureNamespace(root);

            PDStructureElement rootElem = new PDStructureElement(StandardStructureTypes.DOCUMENT, null);

            String lang = _doc.getDocumentElement().getAttribute("lang");
            rootElem.setLanguage(lang.isEmpty() ? "EN-US" : lang);

            root.appendKid(rootElem);

            _root.elem = rootElem;
            sortChildrenByDomOrder(_root);
            finishTreeItems(_root.children, _root);

            // Post-pass over the finished tree so every element creation path is covered.
            if (structureNamespace != null) {
                applyStructureNamespace(rootElem, structureNamespace);
            }

            _od.getWriter().getDocumentCatalog().setStructureTreeRoot(root);
        }
    }

    /**
     * The content painted from now on goes into this transparency group's form, drawn
     * with <code>stream</code>, until {@link #endGroup()}.
     */
    public void startGroup(PdfContentStreamAdapter stream, PDFormXObject form) {
        _outerStreams.push(new StreamTarget(_cs, _nextMcid, _streamItems));
        _cs = stream;
        _nextMcid = 0;
        _streamItems = new PageItems(form);
        _groupItems.add(_streamItems);
    }

    /**
     * Marked content goes back into the stream it went into before the matching
     * {@link #startGroup(PdfContentStreamAdapter, PDFormXObject)}.
     */
    public void endGroup() {
        StreamTarget outer = _outerStreams.pop();
        _cs = outer.cs;
        _nextMcid = outer.nextMcid;
        _streamItems = outer.items;
    }

    /**
     * Creates the PDF 2.0 standard structure namespace dictionary and registers it in
     * the structure tree root's /Namespaces array. Returns null for PDF/UA-1, where no
     * namespace is used. The returned dictionary is shared by reference, so PDFBox writes
     * it as a single indirect object that every /NS entry then references.
     */
    private COSDictionary createPdf2StructureNamespace(PDStructureTreeRoot root) {
        if (_pdfUaVersion < 2) {
            return null;
        }

        COSDictionary namespace = new COSDictionary();
        namespace.setItem(COSName.TYPE, COSName.getPDFName("Namespace"));
        namespace.setString(NS, PDF2_STRUCTURE_NAMESPACE);

        COSArray namespaces = new COSArray();
        namespaces.add(namespace);
        root.getCOSObject().setItem(COSName.getPDFName("Namespaces"), namespaces);

        return namespace;
    }

    private void applyStructureNamespace(PDStructureElement elem, COSDictionary namespace) {
        elem.getCOSObject().setItem(NS, namespace);

        List<Object> kids = elem.getKids();
        if (kids == null) {
            return;
        }

        for (Object kid : kids) {
            if (kid instanceof PDStructureElement) {
                applyStructureNamespace((PDStructureElement) kid, namespace);
            }
        }
    }

    public void finishNumberTree() {
        COSArray numTree = new COSArray();
        int i = 0;

        for (Map.Entry<PDPage, PageItems> entry : _pageItemsMap.entrySet()) {
            List<GenericContentItem> pageItems = entry.getValue()._contentItems;
            List<AnnotationWithStructureParent> pageAnnotations = entry.getValue()._pageAnnotations;

            COSArray mcidParentReferences = new COSArray();

            for (GenericContentItem contentItem : pageItems) {
                mcidParentReferences.add(contentItem.parentElem);
            }

            numTree.add(COSInteger.get(i));
            numTree.add(mcidParentReferences);

            entry.getKey().getCOSObject().setItem(COSName.STRUCT_PARENTS, COSInteger.get(i));
            entry.getKey().getCOSObject().setItem(COSName.getPDFName("Tabs"), COSName.S);
            i++;

            for (AnnotationWithStructureParent annot : pageAnnotations) {
                numTree.add(COSInteger.get(i));
                numTree.add(annot.structureParent);
                annot.annotation.setStructParent(i);
                i++;
            }
        }

        // A transparency group's form holds its own marked content, so it has its own
        // entry, as a page does (14.7.4.4).
        for (PageItems group : _groupItems) {
            COSArray mcidParentReferences = new COSArray();

            for (GenericContentItem contentItem : group._contentItems) {
                mcidParentReferences.add(contentItem.parentElem);
            }

            numTree.add(COSInteger.get(i));
            numTree.add(mcidParentReferences);
            group._form.getCOSObject().setItem(COSName.STRUCT_PARENTS, COSInteger.get(i));
            i++;
        }

        COSDictionary dict = new COSDictionary();
        dict.setItem(COSName.NUMS, numTree);

        PDNumberTreeNode numberTreeNode = new PDNumberTreeNode(dict, dict.getClass());
        _od.getWriter().getDocumentCatalog().getStructureTreeRoot().setParentTreeNextKey(i);
        _od.getWriter().getDocumentCatalog().getStructureTreeRoot().setParentTree(numberTreeNode);
    }

    /**
     * True if this box is a &lt;br&gt; element's layout box, or the anonymous inline box
     * generated for its <code>:before</code> content (which is how forced line breaks are
     * implemented, see <code>br:before</code> in the default stylesheet). Such boxes carry
     * no visible text-level semantic of their own and should not become Span structure
     * elements. Fixes https://github.com/openhtmltopdf/openhtmltopdf/issues/100
     */
    private static boolean isBrGeneratedContent(Box box) {
        if (box.getElement() != null) {
            return "br".equals(box.getElement().getTagName());
        }

        Box parent = box.getParent();
        return parent != null &&
               parent.getElement() != null &&
               "br".equals(parent.getElement().getTagName());
    }

    private static String guessBoxTag(Box box) {
        if (box instanceof BlockBox) {
            BlockBox block = (BlockBox) box;

            if (block.isInline()) {
                return StandardStructureTypes.SPAN;
            } else {
                return StandardStructureTypes.DIV;
            }
        } else {
            return StandardStructureTypes.SPAN;
        }
    }

    /**
     * Recursively sorts children of GenericStructualElement nodes by DOM document order.
     * This fixes PDF/UA-1 rule 7.4.2-1 where structure tree order must follow logical
     * reading order (DOM order), not CSS paint order.
     *
     * Table and list structures are excluded as they have their own semantic ordering.
     */
    private static void sortChildrenByDomOrder(AbstractStructualElement element) {
        if (element instanceof GenericStructualElement) {
            GenericStructualElement generic = (GenericStructualElement) element;
            sortByDomOrder(generic.children);
            for (AbstractTreeItem child : generic.children) {
                if (child instanceof AbstractStructualElement) {
                    sortChildrenByDomOrder((AbstractStructualElement) child);
                }
            }
        } else if (element instanceof ListStructualElement) {
            ListStructualElement list = (ListStructualElement) element;
            sortByDomOrder(list.listItems);
            for (ListItemStructualElement item : list.listItems) {
                sortChildrenByDomOrder(item);
            }
        } else if (element instanceof DescriptionListStructualElement) {
            DescriptionListStructualElement list = (DescriptionListStructualElement) element;
            sortByDomOrder(list.children);
            for (AbstractTreeItem child : list.children) {
                if (child instanceof AbstractStructualElement) {
                    sortChildrenByDomOrder((AbstractStructualElement) child);
                }
            }
        } else if (element instanceof ListItemStructualElement) {
            ListItemStructualElement item = (ListItemStructualElement) element;
            sortChildrenByDomOrder(item.body);
        } else if (element instanceof TableStructualElement) {
            TableStructualElement table = (TableStructualElement) element;
            sortByDomOrder(table.tbodies);
            sortChildrenByDomOrder(table.thead);
            for (TableBodyStructualElement tbody : table.tbodies) {
                sortChildrenByDomOrder(tbody);
            }
            sortChildrenByDomOrder(table.tfoot);
        }
    }

    /**
     * Sorts items that have a DOM node by document order, leaving items
     * without a DOM node (anonymous boxes, text runs) in their original
     * positions. This avoids Comparator transitivity issues that arise
     * when mixing DOM-based and index-based ordering in a single sort.
     */
    private static <T extends AbstractTreeItem> void sortByDomOrder(List<T> children) {
        if (children.size() < 2) {
            return;
        }

        // Collect anchored items (those with a DOM node) and their positions.
        List<Integer> anchoredIndices = new ArrayList<>();
        List<T> anchoredItems = new ArrayList<>();

        for (int i = 0; i < children.size(); i++) {
            if (getDomNode(children.get(i)) != null) {
                anchoredIndices.add(i);
                anchoredItems.add(children.get(i));
            }
        }

        if (anchoredItems.size() < 2) {
            return;
        }

        // Sort anchored items by DOM document order.
        Collections.sort(anchoredItems, new Comparator<T>() {
            @Override
            public int compare(T a, T b) {
                Node nodeA = getDomNode(a);
                Node nodeB = getDomNode(b);

                short pos = nodeA.compareDocumentPosition(nodeB);
                if ((pos & Node.DOCUMENT_POSITION_FOLLOWING) != 0) {
                    return -1;
                } else if ((pos & Node.DOCUMENT_POSITION_PRECEDING) != 0) {
                    return 1;
                }
                return 0;
            }
        });

        // Write sorted anchored items back into their original slots.
        for (int i = 0; i < anchoredIndices.size(); i++) {
            children.set(anchoredIndices.get(i), anchoredItems.get(i));
        }
    }

    private static Node getDomNode(AbstractTreeItem item) {
        if (item instanceof AbstractStructualElement) {
            Box box = ((AbstractStructualElement) item).box;
            if (box != null && box.getElement() != null) {
                return box.getElement();
            }
        }
        return null;
    }

    /**
     * Walks up the DOM from the box's element looking for an {@code <a>} ancestor.
     * Returns the anchor element or null if not found.
     */
    private static org.w3c.dom.Element findAnchorAncestor(Box box) {
        if (box == null || box.getElement() == null) {
            return null;
        }
        org.w3c.dom.Node node = box.getElement();
        while (node != null) {
            if (node instanceof org.w3c.dom.Element && "a".equals(((org.w3c.dom.Element) node).getTagName())) {
                return (org.w3c.dom.Element) node;
            }
            node = node.getParentNode();
        }
        return null;
    }

    /**
     * Ensures a /Link structure element exists for a running content anchor.
     * On the first page, creates the structure element and attaches it to the root.
     * On subsequent pages, reuses the existing one.
     */
    private void ensureRunningLinkStructure(Box box, org.w3c.dom.Element anchorElem) {
        if (_runningLinkStructure != null && _runningLinkDomElement == anchorElem) {
            return; // Already set up for this anchor on this page.
        }

        // Running content box objects are re-created per page, so we track by DOM element.
        AnchorStuctualElement cached = _runningLinkCache.get(anchorElem);
        if (cached != null) {
            _runningLinkStructure = cached;
        } else {
            AnchorStuctualElement struct = new AnchorStuctualElement();
            struct.page = _page;
            struct.box = box;
            struct.setPdfVersion(_od.getWriter().getVersion());
            _root.addChild(struct);
            struct.parent = _root;
            _runningLinkCache.put(anchorElem, struct);
            _runningLinkStructure = struct;
        }
        _runningLinkDomElement = anchorElem;

        // Set the accessibility object on the current page's anchor box so that
        // addLink() can find the /Link structure element via getStructualElementForBox().
        // Running content re-creates box objects per page, so this must be done every time.
        Box anchorBox = findAnchorBox(box, anchorElem);
        if (anchorBox != null) {
            anchorBox.setAccessiblityObject(_runningLinkStructure);
        }
    }

    /**
     * Walks up from a box to find the box whose element matches the anchor element.
     */
    private static Box findAnchorBox(Box box, org.w3c.dom.Element anchorElem) {
        Box current = box;
        while (current != null) {
            if (current.getElement() == anchorElem) {
                return current;
            }
            current = current.getParent();
        }
        return null;
    }

    private GenericContentItem createRunningLinkContentItem() {
        GenericContentItem current = new GenericContentItem();
        _runningLinkStructure.addChild(current);
        current.parent = _runningLinkStructure;
        current.mcid = _nextMcid;
        current.dict = createMarkedContentDictionary();
        current.page = _page;
        addContentItem(current);
        return current;
    }

    /**
     * Creates a /Figure structure element under the running /Link for REPLACED (image) content.
     * This preserves alt text and BBox semantics that would be lost with a plain GenericContentItem.
     */
    private FigureContentItem createRunningLinkFigureItem(Box box) {
        FigureStructualElement figure = new FigureStructualElement();
        figure.page = _page;
        figure.box = box;

        Rectangle2D rect = PdfBoxFastLinkManager.createTargetArea(
                _ctx, box, _pageHeight, _transform, _ctx.getPage(), _od);
        figure.boundingBox = new PDRectangle(
                (float) rect.getMinX(),
                (float) rect.getMinY(),
                (float) rect.getWidth(),
                (float) rect.getHeight());

        _runningLinkStructure.addChild(figure);
        figure.parent = _runningLinkStructure;

        FigureContentItem content = new FigureContentItem();
        figure.addChild(content);
        content.parent = figure;
        content.mcid = _nextMcid;
        content.dict = createMarkedContentDictionary();
        content.page = _page;
        figure.content = content;

        addContentItem(content);
        return content;
    }

    private static void finishTreeItems(List<? extends AbstractTreeItem> children, AbstractStructualElement parent) {
        for (AbstractTreeItem child : children) {
            child.finish(parent);
        }
    }

    private static void finishTreeItem(AbstractTreeItem item, AbstractStructualElement parent) {
        item.finish(parent);
    }

    private void addContentItem(GenericContentItem item) {
        item.form = _streamItems._form;
        _streamItems._contentItems.add(item);
    }

    private COSDictionary createMarkedContentDictionary() {
        COSDictionary dict = new COSDictionary();
        dict.setInt(COSName.MCID, _nextMcid);
        _nextMcid++;
        return dict;
    }

    private void ensureAncestorTree(AbstractTreeItem child, Box parent) {
        // Walk up the ancestor tree making sure they all have accessibility objects.
        // When the walk terminates because an ancestor already has an accessibility
        // object, the most-recently-created intermediate (`child` after the loop)
        // must be linked into that existing ancestor's children list.
        AbstractTreeItem original = child;
        while (parent != null && parent.getAccessibilityObject() == null) {
            AbstractStructualElement parentItem = createStructureItem(null, parent);
            parent.setAccessiblityObject(parentItem);

            parentItem.addChild(child);

            child.parent = parentItem;
            child = parentItem;
            parent = getStructuralParent(parent);
        }

        // Only re-link if the loop actually created intermediates. For callers
        // whose direct parent already has an accessibility object (e.g.
        // createMarkedContentStructureItem) the caller adds `original` itself,
        // so re-linking here would duplicate the entry under /K.
        if (child != original && parent != null && child.parent == null) {
            AbstractStructualElement existing =
                    (AbstractStructualElement) parent.getAccessibilityObject();
            if (existing != null) {
                existing.addChild(child);
                child.parent = existing;
            }
        }
    }

    private AbstractStructualElement createStructureItem(StructureType type, Box box) {
            AbstractStructualElement child = null;

            if (box instanceof BlockBox) {
                BlockBox bb = (BlockBox) box;

                if (bb.isReplaced()) {
                    // For replaced elements we will need to create a BBox.
                    // This is done here so we don'thave to hang onto the page height, transform, etc.
                    Rectangle2D rect = PdfBoxFastLinkManager.createTargetArea(
                            _ctx, box, _pageHeight, _transform, _ctx.getPage(), _od);

                    child = new FigureStructualElement();
                    ((FigureStructualElement) child).boundingBox = new PDRectangle(
                            (float) rect.getMinX(),
                            (float) rect.getMinY(),
                            (float) rect.getWidth(),
                            (float) rect.getHeight());
                }
            }

            // Generated content (::before, ::after) has its originating element, but is
            // not that element: an absolutely positioned li::before must not become a
            // second LI. See GH issue #96.
            if (child == null && box.getElement() != null && !box.isAnonymous() &&
                box.getPseudoElementOrClass() == null) {
                String htmlTag = box.getElement().getTagName();
                Supplier<AbstractStructualElement> supplier = _tagSuppliers.get(htmlTag);

                if (supplier != null) {
                    child = supplier.get();
                }
            }

            if (child == null &&
                box.getParent() != null &&
                box.getParent().getAccessibilityObject() instanceof TableStructualElement) {

                TableStructualElement table = (TableStructualElement) box.getParent().getAccessibilityObject();

                table.setPdfVersion(_od.getWriter().getVersion());

                if (box.getStyle().isIdent(CSSName.DISPLAY, IdentValue.TABLE_HEADER_GROUP)) {
                    child = table.thead;
                } else if (box.getStyle().isIdent(CSSName.DISPLAY, IdentValue.TABLE_ROW_GROUP)) {
                    child = new TableBodyStructualElement();
                } else if (box.getStyle().isIdent(CSSName.DISPLAY, IdentValue.TABLE_FOOTER_GROUP)) {
                    child = table.tfoot;
                }
            }


            if (child == null) {
                child = new GenericStructualElement();
            }

            child.page = _page;
            child.box = box;
            child.setPdfVersion(_od.getWriter().getVersion());

            return child;
    }

    /**
     * The box whose structure element holds this box's: its parent, or for an
     * absolutely positioned box, which has none, its containing block. A box fixed to
     * the page has neither, so its structure goes to the root.
     */
    private static Box getStructuralParent(Box box) {
        if (box.getParent() != null) {
            return box.getParent();
        }
        Box containingBlock = box.getContainingBlock();
        return containingBlock instanceof ViewportBox ? null : containingBlock;
    }

    private void setupStructureElement(AbstractStructualElement child, Box box) {
        box.setAccessiblityObject(child);

        ensureAncestorTree(child, getStructuralParent(box));
        ensureParent(box, child);
    }

    private void ensureParent(Box box, AbstractTreeItem child) {
        if (child.parent == null) {
            if (child instanceof TableHeadStructualElement ||
                child instanceof TableFootStructualElement) {
                child.parent = (TableStructualElement) box.getParent().getAccessibilityObject();
            } else if (child instanceof TableBodyStructualElement) {
                child.parent = (TableStructualElement) box.getParent().getAccessibilityObject();
                ((TableStructualElement) child.parent).tbodies.add((TableBodyStructualElement) child);
            } else if (getStructuralParent(box) != null) {
                AbstractStructualElement parent = (AbstractStructualElement) getStructuralParent(box).getAccessibilityObject();
                parent.addChild(child);
                child.parent = parent;
            } else {
                _root.children.add(child);
                child.parent = _root;
            }
        }
    }

    private GenericContentItem createMarkedContentStructureItem(StructureType type, Box box) {
        GenericContentItem current = new GenericContentItem();

        ensureAncestorTree(current, box.getParent());

        AbstractStructualElement parent = (AbstractStructualElement) box.getAccessibilityObject();
        parent.addChild(current);

        current.parent = parent;
        current.mcid = _nextMcid;
        current.dict = createMarkedContentDictionary();
        current.page = _page;

        addContentItem(current);

        return current;
    }

    private GenericContentItem createListItemLabelMarkedContent(StructureType type, Box box) {
        GenericContentItem current = new GenericContentItem();

        current.mcid = _nextMcid;
        current.dict = createMarkedContentDictionary();
        current.page = _page;

        ListItemStructualElement li = (ListItemStructualElement) box.getAccessibilityObject();
        li.label.addChild(current);
        current.parent = li.label;

        addContentItem(current);

        return current;
    }

    private FigureContentItem createFigureContentStructureItem(StructureType type, Box box) {
        FigureStructualElement parent = (FigureStructualElement) box.getAccessibilityObject();

        if (parent == null ||
            parent.content != null) {
            // This figure structual element already has an image associatted with it.
            // Images continued on subsequent pages will be treated as artifacts.
            return null;
        }

        FigureContentItem current = new FigureContentItem();

        ensureAncestorTree(current, box.getParent());

        current.parent = parent;
        current.mcid = _nextMcid;
        current.dict = createMarkedContentDictionary();
        current.page = _page;

        parent.content = current;

        addContentItem(current);

        return current;
    }

    private COSDictionary createBackgroundArtifact(StructureType type, Box box) {
        Rectangle2D rect = PdfBoxFastLinkManager.createTargetArea(_ctx, box, _pageHeight, _transform, _ctx.getPage(), _od);
        PDRectangle pdRect = new PDRectangle((float) rect.getMinX(), (float) rect.getMinY(), (float) rect.getWidth(), (float) rect.getHeight());

        COSDictionary dict = new COSDictionary();
        dict.setItem(COSName.TYPE, COSName.BACKGROUND);
        dict.setItem(COSName.BBOX, pdRect);

        return dict;
    }

    private COSDictionary createPaginationArtifact() {
        COSDictionary dict = new COSDictionary();
        dict.setItem(COSName.TYPE, COSName.getPDFName("Pagination"));
        return dict;
    }

    private COSDictionary createLineBreakArtifact() {
        // "Layout" is one of the standard Artifact Type values (PDF32000-1, 14.8.2.2.2)
        // for content that is part of the page layout but not real, taggable content -
        // which is exactly what a <br>'s generated line-break content is.
        COSDictionary dict = new COSDictionary();
        dict.setItem(COSName.TYPE, COSName.getPDFName("Layout"));
        return dict;
    }

    private static class Token {
    }

    private static final Token TRUE_TOKEN = new Token();
    private static final Token FALSE_TOKEN = new Token();
    private static final Token INSIDE_RUNNING = new Token();
    private static final Token STARTING_RUNNING = new Token();
    private static final Token NESTED_RUNNING = new Token();
    private static final Token RUNNING_LINK_TEXT = new Token();

    public Token startStructure(StructureType type, Box box) {
            // Check for items that appear on every page (fixed, running, page margins).
            if (type == StructureType.RUNNING) {
                // Only mark artifact for first level of running element (we might have
                // nested fixed elements).
                if (_runningLevel == 0) {
                    _runningLevel++;
                    COSDictionary run = createPaginationArtifact();
                    _cs.beginMarkedContent(COSName.ARTIFACT, run);
                    return STARTING_RUNNING;
                }

                _runningLevel++;
                return NESTED_RUNNING;
            } else if (_runningLevel > 0) {
                // We are in a running artifact.
                // Detect content inside anchor elements to create /Link structure (PDF/UA-1 §7.18).
                // Note: SimplePainter (used for running content) doesn't emit INLINE structure
                // calls, so we detect anchors at the TEXT/REPLACED level via DOM ancestry.
                if (type == StructureType.TEXT || type == StructureType.REPLACED) {
                    org.w3c.dom.Element anchorElem = findAnchorAncestor(box);
                    if (anchorElem != null) {
                        ensureRunningLinkStructure(box, anchorElem);
                        // Temporarily close the artifact BMC.
                        _cs.endMarkedContent();
                        // Create content item attached to the /Link structure element.
                        GenericContentItem current;
                        String tag;
                        if (type == StructureType.REPLACED) {
                            // Use FigureStructualElement to preserve alt text and BBox.
                            current = createRunningLinkFigureItem(box);
                            tag = StandardStructureTypes.Figure;
                        } else {
                            current = createRunningLinkContentItem();
                            tag = StandardStructureTypes.SPAN;
                        }
                        _cs.beginMarkedContent(COSName.getPDFName(tag), current.dict);
                        return RUNNING_LINK_TEXT;
                    }
                }

                return INSIDE_RUNNING;
            }

            switch (type) {
            case LAYER:
            case FLOAT:
            case BLOCK:
            case INLINE:
            case INLINE_CHILD_BOX: {
                AbstractStructualElement struct = (AbstractStructualElement) box.getAccessibilityObject();
                if (struct == null) {
                    struct = createStructureItem(type, box);
                    setupStructureElement(struct, box);
                }
                return FALSE_TOKEN;
            }
            case BACKGROUND: {
                if (box.hasNonTextContent(_ctx)) {
                    COSDictionary current = createBackgroundArtifact(type, box);
                    _cs.beginMarkedContent(COSName.ARTIFACT, current);
                    return TRUE_TOKEN;
                }
                return FALSE_TOKEN;
            }
            case LIST_MARKER: {
                if (box instanceof BlockBox) {
                    MarkerData markers = ((BlockBox) box).getMarkerData();

                    if (markers == null ||
                        (markers.getGlyphMarker() == null &&
                         markers.getTextMarker() == null &&
                         markers.getImageMarker() == null)) {
                        return FALSE_TOKEN;
                    }
                }

                GenericContentItem current = createListItemLabelMarkedContent(type, box);
                _cs.beginMarkedContent(COSName.getPDFName("Span"), current.dict);
                return TRUE_TOKEN;
            }
            case TEXT: {
                if (isBrGeneratedContent(box)) {
                    // A <br>'s own box, and the invisible box generated for its :before
                    // content implementing the forced line break, have no real text-level
                    // content. Marking them as Span content (as we did before) produced a
                    // /Span <</MCID n>> BDC immediately followed by EMC with nothing drawn
                    // in between, which PDF/UA checkers flag as an inappropriate/empty
                    // Span. Mark it as a Layout artifact instead - no MCID, no structure
                    // element, entirely excluded from the tag tree. See GH issue #100.
                    COSDictionary artifact = createLineBreakArtifact();
                    _cs.beginMarkedContent(COSName.ARTIFACT, artifact);
                    return TRUE_TOKEN;
                } else if (isTableLayoutArtifact(box)) {
                    COSDictionary artifact = createPaginationArtifact();
                    _cs.beginMarkedContent(COSName.ARTIFACT, artifact);
                    return TRUE_TOKEN;
                }
                GenericContentItem current = createMarkedContentStructureItem(type, box);
                _cs.beginMarkedContent(COSName.getPDFName(StandardStructureTypes.SPAN), current.dict);
                return TRUE_TOKEN;
            }
            case REPLACED: {
                // For tables pagination might be active and for footer images
                // the last image should be considered as the "real" image, not
                // the previous repeated entries.
                if (isTableLayoutArtifact(box)) {
                    COSDictionary artifact = createPaginationArtifact();
                    _cs.beginMarkedContent(COSName.ARTIFACT, artifact);
                    return TRUE_TOKEN;
                }

                AbstractStructualElement struct = (AbstractStructualElement) box.getAccessibilityObject();
                if (struct == null) {
                    struct = createStructureItem(type, box);
                    setupStructureElement(struct, box);
                }

                FigureContentItem current = createFigureContentStructureItem(type, box);

                if (current != null) {
                    _cs.beginMarkedContent(COSName.getPDFName(StandardStructureTypes.Figure), current.dict);
                    return TRUE_TOKEN;
                } else {
                    // For images that continue over more than one page, just mark the portion on the second
                    // and subsequent pages as an artifact. The spec (PDF 1.7) is not clear on what to do in this
                    // situation.
                    COSDictionary bg = createBackgroundArtifact(type, box);
                    _cs.beginMarkedContent(COSName.ARTIFACT, bg);
                    return TRUE_TOKEN;
                }
            }
            default: {
                return FALSE_TOKEN;
            }
            }
    }

    public void endStructure(Object token) {
        Token value = (Token) token;

        if (value == TRUE_TOKEN) {
            _cs.endMarkedContent();
        } else if (value == FALSE_TOKEN ||
                   value == INSIDE_RUNNING) {
            // do nothing...
        } else if (value == NESTED_RUNNING) {
            _runningLevel--;
        } else if (value == STARTING_RUNNING) {
            _runningLevel--;
            _runningLinkStructure = null;
            _runningLinkDomElement = null;
            _cs.endMarkedContent();
        } else if (value == RUNNING_LINK_TEXT) {
            // Close the Span marked content for the link text.
            _cs.endMarkedContent();
            // Re-open the pagination artifact BMC.
            COSDictionary dict = createPaginationArtifact();
            _cs.beginMarkedContent(COSName.ARTIFACT, dict);
        }
    }

    public void startPage(PDPage page, PdfContentStreamAdapter cs, RenderingContext ctx, float pageHeight, AffineTransform transform) {
        this._cs = cs;
        this._ctx = ctx;
        this._nextMcid = 0;
        this._page = page;
        this._pageHeight = pageHeight;
        this._transform = transform;
        this._pageItems = new PageItems(null);
        this._pageItemsMap.put(page, this._pageItems);
        this._streamItems = this._pageItems;
        this._runningLinkStructure = null;
        this._runningLinkDomElement = null;
    }

    public void endPage() {

    }

    private static class AnnotationWithStructureParent {
        PDStructureElement structureParent;
        PDAnnotation annotation;
    }

    public void addLink(Box anchor, Box target, PDAnnotation pdAnnotation, PDPage page) {
        PDStructureElement struct = getStructualElementForBox(anchor);

        // For running content links, the anchor box may not have its accessibility object set
        // (e.g. image-only links where the <a> box is in a different parent chain than the <img> box).
        // Fall back to the running link cache using the DOM element.
        if (struct == null && anchor.getElement() != null) {
            org.w3c.dom.Element anchorElem = findAnchorAncestor(anchor);
            if (anchorElem != null) {
                AnchorStuctualElement cached = _runningLinkCache.get(anchorElem);
                if (cached != null) {
                    struct = cached.elem;
                }
            }
        }

        if (struct != null) {
            // We have to append the link annotationobject reference as a kid of its associated structure element.
            PDObjectReference ref = new PDObjectReference();
            ref.setReferencedObject(pdAnnotation);
            struct.appendKid(ref);

            // We also need to save the pair so we can add it to the number tree for reverse lookup.
            AnnotationWithStructureParent annotStructParentPair = new AnnotationWithStructureParent();
            annotStructParentPair.annotation = pdAnnotation;
            annotStructParentPair.structureParent = struct;

            _pageItems._pageAnnotations.add(annotStructParentPair);
        }
    }

    public void setDisplayListContainer(DisplayListContainer displayListContainer) {
        // see #isTableLayoutArtifact
        IdentityHashMap<Box, List<Integer>> boxToPageMappingBuilder = new IdentityHashMap<>();
        for(int i = displayListContainer.getMinPage(); i <= displayListContainer.getMaxPage(); i++) {
            final int currentIdx = i;
            displayListContainer
                    .getPageInstructions(i)
                    .getOperations()
                    .stream()
                    .filter(dlo -> dlo instanceof PaintInlineContent)
                    .map(dlo -> (PaintInlineContent) dlo)
                    .flatMap(pic -> pic.getInlines().stream())
                    .filter(dli -> dli instanceof Box)
                    .map(dli -> (Box) dli)
                    .forEach(b -> boxToPageMappingBuilder.computeIfAbsent(b, b2 -> new ArrayList<>()).add(currentIdx));
        }
        _boxToPageMapping = boxToPageMappingBuilder;
    }

    private boolean isInTableHeader(Box currentBox) {
        return isInTableHeaderOrFooter(currentBox, "thead");
    }

    private boolean isInTableFooter(Box currentBox) {
        return isInTableHeaderOrFooter(currentBox, "tfoot");
    }

    private boolean isInTableHeaderOrFooter(Box currentBox, String targetElement) {
        if (currentBox == null) {
            return false;
        } else if (currentBox.getElement() != null
                && targetElement.equals(currentBox.getElement().getTagName())) {
            return true;
        } else {
            return isInTableHeaderOrFooter(currentBox.getParent(), targetElement);
        }
    }

    private boolean isInPaginatedTable(Box box) {
        if(box == null) {
            return false;
        } else if(box instanceof TableBox) {
            return box.getStyle().isPaginateTable();
        } else {
            return isInPaginatedTable(box.getParent());
        }
    }

    private boolean isTableLayoutArtifact(Box box) {
        // If a table is styled with the CSS property "-fs-table-paginate" set to
        // "paginate", this causes the table headers and footers to be repeated on
        // each page the table covers.
        //
        // For the page structure tree the entries must only be represented once.
        // If each copy is included in the structure tree, the headers and footers
        // are represented multiple times. This is especially a problem for table
        // header as the headers are read for each cell.
        //
        // The contents that is only generated as part of the paging must be marked
        // as a paging artifact, so that it is not represented in the page structure
        //
        // When creating the page structure items we need to check if this box
        // is part of a paginated header or footer and if this the first or last
        // page where this content is drawn.
        List<Integer> pageUsages = _boxToPageMapping.get(box);
        if (pageUsages == null) {
            return false;
        }
        if (!isInPaginatedTable(box)) {
            return false;
        }
        boolean isInTableHeader = isInTableHeader(box);
        boolean isInTableFooter = isInTableFooter(box);
        if(! (isInTableFooter || isInTableHeader)) {
            return false;
        }
        if(isInTableHeader) {
            // Header content is only drawn on the first usage page
            return pageUsages.get(0) != _ctx.getPageNo();
        } else { // isFooter
            // Footer content is only drawn on the last usage page
            return pageUsages.get(pageUsages.size() - 1) != _ctx.getPageNo();
        }
    }

}
