/*
 * {{{ header & license
 * Copyright (c) 2007 Wisconsin Court System
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * }}}
 */
package com.openhtmltopdf.newtable;

import java.awt.Rectangle;
import java.io.IOException;
import java.io.Writer;
import java.util.List;

import com.openhtmltopdf.css.constants.CSSName;
import com.openhtmltopdf.css.constants.IdentValue;
import com.openhtmltopdf.css.style.CssContext;
import com.openhtmltopdf.css.style.derived.BorderPropertySet;
import com.openhtmltopdf.css.style.derived.RectPropertySet;
import com.openhtmltopdf.layout.LayoutContext;
import com.openhtmltopdf.render.BlockBox;
import com.openhtmltopdf.render.Box;
import com.openhtmltopdf.render.ContentLimitContainer;
import com.openhtmltopdf.render.PageBox;
import com.openhtmltopdf.render.RenderingContext;

public class TableRowBox extends BlockBox {
    private int _baseline;
    private boolean _haveBaseline = false;
    private int _heightOverride;
    private ContentLimitContainer _contentLimitContainer;

    private boolean _fitsOnAPage = true;
    private boolean _startsOnHeadPage = false;
    
    private int _extraSpaceTop;
    private int _extraSpaceBottom;
    
    public TableRowBox() {
    }
    
    @Override
    public BlockBox copyOf() {
        TableRowBox result = new TableRowBox();
        result.setStyle(getStyle());
        result.setElement(getElement());
        
        return result;
    }
    
    private Iterable<TableCellBox> getTableCells() {
        return () -> getChildIteratorOfType(TableCellBox.class);
    }
    
    @Override
    public boolean isAutoHeight() {
        return getStyle().isAutoHeight() || ! getStyle().hasAbsoluteUnit(CSSName.HEIGHT);
    }
    
    private TableBox getTable() {
        // row -> section -> table
        return (TableBox)getParent().getParent();
    }
    
    private TableSectionBox getSection() {
        return (TableSectionBox)getParent();
    }
    
    @Override
    public void layout(LayoutContext c, int contentStart) {
        boolean running = c.isPrint() && getTable().getStyle().isPaginateTable();
        int prevExtraTop = 0;
        int prevExtraBottom = 0;
        
        if (running) {
            prevExtraTop = c.getExtraSpaceTop();
            prevExtraBottom = c.getExtraSpaceBottom();

            clearRepeatedHeader(c);

            calcExtraSpaceTop(c);
            calcExtraSpaceBottom(c);
            
            c.setExtraSpaceTop(c.getExtraSpaceTop() + getExtraSpaceTop());
            c.setExtraSpaceBottom(c.getExtraSpaceBottom() + getExtraSpaceBottom());
        }
        
        super.layout(c, contentStart);

        boolean firstBodyRow = getTable().getFirstBodyRow() == this;

        // Position-agnostic layouts (the running header/footer trials, repeated section
        // repositioning) set noPageBreak; reacting to the page geometry there would bake a
        // phantom straddle gap into the section's height.
        if (c.isPrint() && c.isPageBreaksAllowed() && firstBodyRow) {
            // Measured before the running extra space is restored below, and kept across the
            // relayout -- so not cleared in reset() -- because BlockBoxing asks for the page
            // clear before it lays the row out again. Measured for any table, not just a
            // paginated one, since the escalations this gates are not restricted either.
            _fitsOnAPage = !measureTallerThanPage(c);

            if (!isHeaderStrandedAbove(c)) {
                // The row is on the head's page here, which is its natural position: the
                // stranded-head rescue below also runs from BlockBoxing's page-clear retry,
                // where the row has been moved already and nothing of it could start there
                // by construction. Kept for the same reason as the fit.
                _startsOnHeadPage = !isShouldMoveToNextPage(c);
            }
        }

        if (running) {
            if (c.isPageBreaksAllowed() && isShouldMoveToNextPage(c)) {
                // Nothing of this row can start on this page: move regardless of fit,
                // which setNeedPageClear declines.
                if (firstBodyRow) {
                    escalatePageClearToTable();
                } else {
                    super.setNeedPageClear(true);
                }
            }
            c.setExtraSpaceTop(prevExtraTop);
            c.setExtraSpaceBottom(prevExtraBottom);
        }

        if (c.isPrint() && c.isPageBreaksAllowed() && firstBodyRow
                && (_fitsOnAPage || !_startsOnHeadPage) && isHeaderStrandedAbove(c)) {
            // A head that ends in the last sliver of a page while the first body row
            // begins on the next one strands the head without any page-clear event
            // the escalations above could react to: the row was laid on its natural
            // page and never "moved". Only a header that ends above this row's page
            // needs the rescue -- one that reaches the row's page is split, not
            // stranded (possible with thead { page-break-inside: auto }).
            //
            // A row that cannot fit a page is rescued only when the head's page held no
            // content of it either: then the move costs that page nothing and buys the
            // head its rows. When the row did start there, moving is the skipped page
            // this change is about.
            escalatePageClearToTable();
        }
    }

    /**
     * A body row that starts exactly at the top of a continuation page did not straddle
     * the break, so nothing moved it below the space reserved there for the repeated
     * header and footer furniture. Move it now, as BlockBox.calcExtraPageClearance does
     * for blocks. Otherwise its lines are pushed down inside it, inflating the row, and
     * the header, positioned above the row's top, ends up on the previous page. Issue #271.
     * <br><br>
     * Call before this row adds its own cell border and padding to the extra space.
     */
    private void clearRepeatedHeader(LayoutContext c) {
        if (!c.isPageBreaksAllowed() || c.getExtraSpaceTop() <= 0
                || getSection().isHeader() || getSection().isFooter()) {
            return;
        }

        PageBox page = c.getRootLayer().getFirstPage(c, this);
        if (page == null || getTable().getAbsY() >= page.getTop()) {
            // The table starts on this page: its own header sits above the row.
            return;
        }

        int diff = page.getTop() + c.getExtraSpaceTop() - getAbsY();
        if (diff > 0) {
            setY(getY() + diff);
            c.translate(0, diff);
            calcCanvasLocation();
        }
    }

    /**
     * Whether this row is too tall to sit on a page of its own, under the repeated header
     * and above the repeated footer.
     * <br><br>
     * Call while the context still carries this row's extra space: the reserve passed on is
     * only the furniture a continuation page repeats -- running header and footer, table
     * border and padding -- and not this row's own cell border and padding, which
     * {@link #getHeight()} already includes.
     */
    private boolean measureTallerThanPage(LayoutContext c) {
        PageBox page = c.getRootLayer().getFirstPage(c, this);

        if (page == null) {
            return false;
        }

        return isTallerThanPage(c, page, getHeight(),
                c.getExtraSpaceTop() - getExtraSpaceTop(),
                c.getExtraSpaceBottom() - getExtraSpaceBottom());
    }

    /**
     * Whatever moves the first body row to the next page must move the table with it,
     * or the repeated header stays behind on a page that has no rows. Issue #162.
     */
    private void escalatePageClearToTable() {
        // XXX Performance problem here.  This forces the table to move to the next page
        // (which we want), but the initial table layout run still completes (which we don't)
        getTable().setNeedPageClear(true);
    }

    private boolean isHeaderStrandedAbove(LayoutContext c) {
        TableBox table = getTable();
        if (table.getChildCount() == 0) {
            return false;
        }
        Box first = table.getChild(0);
        if (!(first instanceof TableSectionBox) || ! ((TableSectionBox)first).isHeader()) {
            return false;
        }
        PageBox rowPage = c.getRootLayer().getFirstPage(c, this);
        return rowPage != null && first.getAbsY() + first.getHeight() <= rowPage.getTop();
    }

    @Override
    public void setNeedPageClear(boolean needPageClear) {
        if (needPageClear && getTable().getFirstBodyRow() == this && _fitsOnAPage) {
            // A row that cannot fit a page is excluded: it is split wherever it starts, so
            // moving the table only strands the space this page still had. A head left with
            // nothing under it is instead rescued by isHeaderStrandedAbove.
            escalatePageClearToTable();
        } else {
            super.setNeedPageClear(needPageClear);
        }
    }

    private boolean isShouldMoveToNextPage(LayoutContext c) {
        PageBox page = c.getRootLayer().getFirstPage(c, this);

        if (page == null) {
            return false;
        }

        int pageBottomUsable = page.getBottom(c);

        if (getAbsY() + getHeight() < pageBottomUsable) {
            return false;
        }

        for (TableCellBox cell : getTableCells()) {
            int baseline = cell.calcBlockBaseline(c);
            if (baseline != BlockBox.NO_BASELINE && baseline < pageBottomUsable) {
                return false;
            }
        }

        return true;
    }

    @Override
    public void analyzePageBreaks(LayoutContext c, ContentLimitContainer container) {
        if (getTable().getStyle().isPaginateTable()) {
            _contentLimitContainer = new ContentLimitContainer(c, getAbsY());
            _contentLimitContainer.setParent(container);
            
            if (container != null) {
                container.updateTop(c, getAbsY());
                container.updateBottom(c, getAbsY() + getHeight());
            }
            
            for (Box b : getChildren()) {
                b.analyzePageBreaks(c, _contentLimitContainer);
            }
            
            if (container != null && _contentLimitContainer.isContainsMultiplePages()) {
                propagateExtraSpace(c, container, _contentLimitContainer, getExtraSpaceTop(), getExtraSpaceBottom());
            }
        } else {
            super.analyzePageBreaks(c, container);
        }
    }   

    private void calcExtraSpaceTop(LayoutContext c) {
        int maxBorderAndPadding = 0;
        
        for (TableCellBox cell : getTableCells()) {
            int borderAndPadding = (int)cell.getPadding(c).top() + (int)cell.getBorder(c).top();
            if (borderAndPadding > maxBorderAndPadding) {
                maxBorderAndPadding = borderAndPadding;
            }
        }

        _extraSpaceTop = maxBorderAndPadding;
    }
    
    private void calcExtraSpaceBottom(LayoutContext c) {
        int maxBorderAndPadding = 0;
        
        int cRow = getIndex();
        int totalRows = getSection().numRows();
        List<RowData> grid = getSection().getGrid();
        if ((grid.size() > 0) && (cRow < grid.size())) {
            List<TableCellBox> row = grid.get(cRow).getRow();
            
            for (int cCol = 0; cCol < row.size(); cCol++) {
                TableCellBox cell = row.get(cCol);
                
                if (cell == null || cell == TableCellBox.SPANNING_CELL) {
                    continue;
                }
                if (cRow < totalRows - 1 && getSection().cellAt(cRow+1, cCol) == cell) {
                    continue;
                }
                
                int borderAndPadding = (int)cell.getPadding(c).bottom() + (int)cell.getBorder(c).bottom();
                if (borderAndPadding > maxBorderAndPadding) {
                    maxBorderAndPadding = borderAndPadding;
                }
            }
        }
        
        _extraSpaceBottom = maxBorderAndPadding;
    }

    @Override
    protected void layoutChildren(LayoutContext c, int contentStart) {
        setState(Box.CHILDREN_FLUX);
        ensureChildren(c);

        TableSectionBox section = getSection();
        if (section.isNeedCellWidthCalc()) {
            section.setCellWidths(c);
            section.setNeedCellWidthCalc(false);
        }

        if (getChildrenContentType() != ContentType.EMPTY) {
            for (TableCellBox cell : getTableCells()) {
                layoutCell(c, cell, 0);
            }
        }

        setState(Box.DONE);
    }

    private void alignBaselineAlignedCells(LayoutContext c) {
        int[] baselines = new int[getChildCount()];
        int lowest = Integer.MIN_VALUE;
        boolean found = false;
        for (int i = 0; i < getChildCount(); i++) {
            TableCellBox cell = (TableCellBox)getChild(i);
            
            if (cell.getVerticalAlign() == IdentValue.BASELINE) {
                int baseline = cell.calcBaseline(c);
                baselines[i] = baseline;
                if (baseline > lowest) {
                    lowest = baseline;
                }
                found = true;
            }
        }
        
        if (found) {
            for (int i = 0; i < getChildCount(); i++) {
                TableCellBox cell = (TableCellBox)getChild(i);
                
                if (cell.getVerticalAlign() == IdentValue.BASELINE) {
                    int deltaY = lowest - baselines[i];
                    if (deltaY != 0) {
                        if (c.isPrint() && cell.isPageBreaksChange(c, deltaY)) {
                            relayoutCell(c, cell, deltaY);
                        } else {
                            cell.moveContent(c, deltaY);
                            cell.setHeight(cell.getHeight() + deltaY);
                        }
                    }
                }
            }
        
            setBaseline(lowest - getAbsY());
            setHaveBaseline(true);
        }
    }
    
    private boolean alignMiddleAndBottomAlignedCells(LayoutContext c) {
        boolean needRowHeightRecalc = false;
        
        int cRow = getIndex();
        int totalRows = getSection().numRows();
        List<RowData> grid = getSection().getGrid();
        if ((grid.size() > 0) && (cRow < grid.size())) {
            List<TableCellBox> row = grid.get(cRow).getRow();
            
            for (int cCol = 0; cCol < row.size(); cCol++) {
                TableCellBox cell = row.get(cCol);
                
                if (cell == null || cell == TableCellBox.SPANNING_CELL) {
                    continue;
                }
                if (cRow < totalRows - 1 && getSection().cellAt(cRow+1, cCol) == cell) {
                    continue;
                }
                
                IdentValue val = cell.getVerticalAlign();
                if (val == IdentValue.MIDDLE || val == IdentValue.BOTTOM) {
                    int deltaY = calcMiddleBottomDeltaY(cell, val);
                    if (deltaY > 0) {
                        if (c.isPrint() && cell.isPageBreaksChange(c, deltaY)) {
                            int oldCellHeight = cell.getHeight();
                            relayoutCell(c, cell, deltaY);
                            if (oldCellHeight + deltaY != cell.getHeight()) {
                                needRowHeightRecalc = true;
                            }
                        } else {
                            cell.moveContent(c, deltaY);
                            // Set a provisional height in case we need to calculate
                            // a default baseline
                            cell.setHeight(cell.getHeight() + deltaY);
                        }
                    }
                }
            }
        }
        
        return needRowHeightRecalc;
    }
    
    private int calcMiddleBottomDeltaY(TableCellBox cell, IdentValue verticalAlign) {
        int result;
        if (cell.getStyle().getRowSpan() == 1) {
            result = getHeight() - cell.getChildrenHeight();
        } else {
            result = getAbsY() + getHeight() - (cell.getAbsY() + cell.getChildrenHeight());
        }
        
        if (verticalAlign == IdentValue.MIDDLE) {
            return result / 2;
        } else {  /* verticalAlign == IdentValue.BOTTOM */
            return result;
        }
    }

    @Override
    protected void calcLayoutHeight(
            LayoutContext c, BorderPropertySet border, 
            RectPropertySet margin, RectPropertySet padding) {
        if (getHeightOverride() > 0) {
            setHeight(getHeightOverride());
        }
        
        alignBaselineAlignedCells(c);
        
        calcRowHeight(c);
        
        boolean recalcRowHeight = alignMiddleAndBottomAlignedCells(c);
        
        if (recalcRowHeight) {
            calcRowHeight(c);
        }
        
        if (! isHaveBaseline()) {
            calcDefaultBaseline(c);
        }
        
        setCellHeights(c);
    }

    private void calcRowHeight(CssContext c) {
        int y1 = getAbsY();
        int y2;
        
        if (getHeight() != 0) {
            y2 = y1 + getHeight();
        } else {
            y2 = y1;
        }
        
        if (isLastRow()) {
            int bottom = getTable().calcFixedHeightRowBottom(c);
            if (bottom > 0 && bottom > y2) {
                y2 = bottom;
            }
        }
        
        int cRow = getIndex();
        int totalRows = getSection().numRows();
        List<RowData> grid = getSection().getGrid();
        if ((grid.size() > 0) && (cRow < grid.size())) {
            List<TableCellBox> row = grid.get(cRow).getRow();
            for (int cCol = 0; cCol < row.size(); cCol++) {
                TableCellBox cell = row.get(cCol);
                
                if (cell == null || cell == TableCellBox.SPANNING_CELL) {
                    continue;
                }
                if (cRow < totalRows - 1 && getSection().cellAt(cRow+1, cCol) == cell) {
                    continue;
                }
                
                int bottomCellEdge = cell.getAbsY() + cell.getHeight();
                if (bottomCellEdge > y2) {
                    y2 = bottomCellEdge;
                }
            }
        }
        
        setHeight(y2 - y1);
    }
    
    private boolean isLastRow() {
        TableBox table = getTable();
        TableSectionBox section = getSection();
        if (table.sectionBelow(section, true) == null) {
            return section.getChild(section.getChildCount()-1) == this;
        } else {
            return false;
        }
    }
    
    private void calcDefaultBaseline(LayoutContext c) {
        int lowestCellEdge = 0;
        int cRow = getIndex();
        int totalRows = getSection().numRows();
        List<RowData> grid = getSection().getGrid();
        if ((grid.size() > 0) && (cRow < grid.size())) {
            List<TableCellBox> row = grid.get(cRow).getRow();
            for (int cCol = 0; cCol < row.size(); cCol++) {
                TableCellBox cell = row.get(cCol);
                
                if (cell == null || cell == TableCellBox.SPANNING_CELL) {
                    continue;
                }
                if (cRow < totalRows - 1 && getSection().cellAt(cRow+1, cCol) == cell) {
                    continue;
                }
                
                Rectangle contentArea = cell.getContentAreaEdge(cell.getAbsX(), cell.getAbsY(), c);
                int bottomCellEdge = contentArea.y + contentArea.height;
                if (bottomCellEdge > lowestCellEdge) {
                    lowestCellEdge = bottomCellEdge;
                }
            }
        }
        if (lowestCellEdge > 0) {
            setBaseline(lowestCellEdge - getAbsY());
        }
        setHaveBaseline(true);
    }
    
    private void setCellHeights(LayoutContext c) {
        int cRow = getIndex();
        int totalRows = getSection().numRows();
        List<RowData> grid = getSection().getGrid();
        if ((grid.size() > 0) && (cRow < grid.size())) {
            List<TableCellBox> row = grid.get(cRow).getRow();
            for (int cCol = 0; cCol < row.size(); cCol++) {
                TableCellBox cell = row.get(cCol);
                
                if (cell == null || cell == TableCellBox.SPANNING_CELL) {
                    continue;
                }
                if (cRow < totalRows - 1 && getSection().cellAt(cRow+1, cCol) == cell) {
                    continue;
                }
                
                if (cell.getStyle().getRowSpan() == 1) {
                    cell.setHeight(getHeight());
                } else {
                    cell.setHeight(getAbsY() + getHeight() - cell.getAbsY());
                }
            }
        }
    }
    
    private void relayoutCell(LayoutContext c, TableCellBox cell, int contentStart) {
        int width = cell.getWidth();
        cell.reset(c);
        cell.setLayoutWidth(c, width);
        layoutCell(c, cell, contentStart);
    }
    
    private void layoutCell(LayoutContext c, TableCellBox cell, int contentStart) {
        cell.initContainingLayer(c);
        cell.calcCanvasLocation();
        
        cell.layout(c, contentStart);
    } 

    @Override
    public void initStaticPos(LayoutContext c, BlockBox parent, int childOffset) {
        setX(0);
        
        TableBox table = getTable();
        setY(parent.getHeight() + table.getStyle().getBorderVSpacing(c));
        c.translate(0, getY()-childOffset);
    }

    public int getBaseline() {
        return _baseline;
    }

    public void setBaseline(int baseline) {
        _baseline = baseline;
    }
    
    @Override
    protected boolean isSkipWhenCollapsingMargins() {
        return true;
    }
    
    @Override
    public void paintBorder(RenderingContext c) {
        // rows never have borders
    }
    
    @Override
    public void paintBackground(RenderingContext c) {
        // painted at the cell level
    }   
    
    @Override
    public void reset(LayoutContext c) {
        super.reset(c);
        setHaveBaseline(false);
        getSection().setNeedCellWidthCalc(true);
        setContentLimitContainer(null);
    }

    public boolean isHaveBaseline() {
        return _haveBaseline;
    }

    public void setHaveBaseline(boolean haveBaseline) {
        _haveBaseline = haveBaseline;
    }

    @Override
    protected String getExtraBoxDescription() {
        if (isHaveBaseline()) {
            return "(baseline=" + getBaseline() + ") ";
        } else {
            return "";
        }
    }

    public int getHeightOverride() {
        return _heightOverride;
    }

    public void setHeightOverride(int heightOverride) {
        _heightOverride = heightOverride;
    }
    
    @Override
    public void exportText(RenderingContext c, Writer writer) throws IOException {
        if (getTable().isMarginAreaRoot()) {
            super.exportText(c, writer);
        } else {
            int yPos = getAbsY();
            if (yPos >= c.getPage().getBottom() && isInDocumentFlow()) {
                exportPageBoxText(c, writer, yPos);
            }
            
            for (TableCellBox cell : getTableCells()) {
                StringBuilder buffer = new StringBuilder();
                cell.collectText(c, buffer);
                writer.write(buffer.toString().trim());
                int cSpan = cell.getStyle().getColSpan();
                for (int j = 0; j < cSpan; j++) {
                    writer.write('\t');    
                }
            }
            
            writer.write(LINE_SEPARATOR);
        }
    }

    public ContentLimitContainer getContentLimitContainer() {
        return _contentLimitContainer;
    }

    public void setContentLimitContainer(ContentLimitContainer contentLimitContainer) {
        _contentLimitContainer = contentLimitContainer;
    }

    public int getExtraSpaceTop() {
        return _extraSpaceTop;
    }

    public void setExtraSpaceTop(int extraSpaceTop) {
        _extraSpaceTop = extraSpaceTop;
    }

    public int getExtraSpaceBottom() {
        return _extraSpaceBottom;
    }

    public void setExtraSpaceBottom(int extraSpaceBottom) {
        _extraSpaceBottom = extraSpaceBottom;
    }
    
    @Override
    public int forcePageBreakBefore(LayoutContext c, IdentValue pageBreakValue,
            boolean pendingPageName) {
        int currentDelta = super.forcePageBreakBefore(c, pageBreakValue, pendingPageName);
        
        // additional calculations for collapsed borders.
        if (c.isPrint() && getStyle().isCollapseBorders()) {
            // get destination page for this row
            PageBox page = c.getRootLayer().getPage(c, getAbsY() + currentDelta);
            if (page!=null) {
                
                // calculate max spill from the collapsed top borders of each child
                int spill = 0;
                for (TableCellBox cell : getTableCells()) {
                    BorderPropertySet collapsed = cell.getCollapsedPaintingBorder();
                    if (collapsed != null) {
                        spill = Math.max(spill, (int)collapsed.top() / 2);
                    }
                }
    
                // be sure that the current start of the row is >= the start of the page
                int borderTop = getAbsY() + currentDelta + (int)getMargin(c).top() - spill;
                int rowDelta = page.getTop() - borderTop;
                if (rowDelta > 0) {
                    setY(getY() + rowDelta);
                    currentDelta += rowDelta;
                }
            }
        }
        return currentDelta;
    }
    
    @Override
    protected BlockBox getNextCollapsableSibling(MarginCollapseResult collapsedMargin) {
        return null;
    }
}
